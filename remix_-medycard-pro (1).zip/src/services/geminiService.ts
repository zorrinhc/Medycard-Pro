import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const askMedy = async (prompt: string, context: 'emergency' | 'vault' | 'travel' | 'family' | 'lab' | 'check' | 'journal') => {
  const systemInstructions = {
    emergency: "You are MedyCard Pro's Emergency Assistant. Provide clear, concise first-aid guidance and emergency steps. Always advise calling local emergency services if the situation is life-threatening. Be calm and professional.",
    vault: "You are MedyCard Pro's Security Assistant. Help users understand how to organize their medical records and what information is critical to keep in their vault. Do not ask for actual sensitive data, just guide them on best practices.",
    travel: "You are MedyCard Pro's Travel Guard. Provide health advice for travelers, including common vaccinations, local health risks, and how to find medical help abroad. Use search grounding if needed.",
    family: "You are MedyCard Pro's Family Assistant. Help users manage their emergency contacts and share their location safely with family members.",
    lab: "When a lab report is uploaded, act as a medical assistant. Analyze the results and provide: 1. A clear status (Normal/Caution/Priority), 2. A 2-sentence plain-English summary, and 3. One clear next step. Use a high-contrast layout with color-coded headers (Green/Yellow/Red) for the status.",
    check: "You are MedyCard Pro's Med-Check Assistant. Help users understand medication interactions and potential side effects. Always advise consulting a doctor for medical decisions.",
    journal: "You are MedyCard Pro's Pain & Inflammation Journal Assistant. Support users in tracking their daily pain, symptoms, flare-ups, and daily progress. Help them note potential trigger foods, atmospheric changes, or activities that correlate with their physical state."
  };

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      systemInstruction: systemInstructions[context],
      tools: context === 'travel' ? [{ googleSearch: {} }] : []
    }
  });

  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map(chunk => chunk.web).filter(Boolean) || []
  };
};

export const analyzeLabReport = async (base64Data: string, mimeType: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Data,
            mimeType: mimeType
          }
        },
        {
          text: "Analyze this lab report and provide: 1. A clear status (Normal/Caution/Priority), 2. A 2-sentence plain-English summary, and 3. One clear next step. Use a high-contrast layout with color-coded headers (Green/Yellow/Red) for the status."
        }
      ]
    },
    config: {
      systemInstruction: "When a lab report is uploaded, act as a medical assistant. Analyze the results and provide: 1. A clear status (Normal/Caution/Priority), 2. A 2-sentence plain-English summary, and 3. One clear next step. Use a high-contrast layout with color-coded headers (Green/Yellow/Red) for the status."
    }
  });

  return response.text;
};
