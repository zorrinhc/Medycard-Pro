import React, { useState, useRef, useEffect } from 'react';
import { 
  AlertCircle, 
  ShieldCheck, 
  Globe, 
  Phone, 
  Activity, 
  Lock, 
  FileText, 
  Plane, 
  MapPin, 
  Send,
  Loader2,
  ChevronRight,
  Plus,
  Search,
  ExternalLink,
  Menu,
  X,
  CreditCard,
  Users,
  Camera,
  Stethoscope,
  AlertTriangle,
  Share2,
  Nfc,
  Eye,
  Heart,
  History,
  MessageCircle,
  HelpCircle,
  Trash2
} from 'lucide-react';
import Markdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { askMedy, analyzeLabReport } from './services/geminiService';

import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

type Page = 'emergency' | 'vault' | 'travel' | 'family' | 'lab' | 'check' | 'journal';

interface PainLog {
  id: string;
  date: string;
  pain: number;
  location: string;
  notes: string;
}

interface Message {
  id: string;
  role: 'user' | 'ai';
  content: string;
  sources?: any[];
}

interface Medication {
  id: string;
  name: string;
  dosage: string;
  frequency: string;
  status?: 'safe' | 'caution';
}

interface CaregiverLog {
  id: string;
  name: string;
  time: string;
  action: string;
}

const PrivacyOverlay = ({ children, isActive, label = "ENCRYPTED — TAP FOR ACCESS" }: { children: React.ReactNode, isActive: boolean, label?: string }) => {
  return (
    <div className="relative group overflow-hidden rounded-lg">
      <div className={cn("transition-all duration-500", isActive && "blur-sm select-none")}>
        {children}
      </div>
      <AnimatePresence>
        {isActive && (
          <motion.div
            initial={{ x: 0, opacity: 1 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '110%', opacity: 0 }}
            transition={{ type: 'spring', damping: 30, stiffness: 150 }}
            className="absolute inset-0 z-10 flex items-center justify-center backdrop-blur-xl bg-white/10 border border-blue-500/30 rounded-lg cursor-pointer"
          >
            <div className="flex flex-col items-center gap-1">
              <Lock size={14} className="text-blue-500 group-hover:animate-pulse transition-all" />
              <span className="text-[8px] font-black text-blue-600 tracking-widest uppercase whitespace-nowrap drop-shadow-sm">
                {label}
              </span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

interface OnboardStep {
  icon: string;
  label: string;
  title: string;
  desc: string;
  highlight: string;
  color: string;
  bg: string;
}

const ONBOARD_STEPS: OnboardStep[] = [
  {
    icon: '🚨',
    label: 'THE PROBLEM',
    title: "If you couldn't speak right now...",
    desc: "Every year, people arrive in emergency rooms unable to communicate. Paramedics are guessing. Families are panicking. Doctors are working blind.",
    highlight: 'Would the people trying to save you know what they need to know?',
    color: '#EF4444',
    bg: 'linear-gradient(160deg, #1a0505 0%, #3d0a0a 50%, #7f1d1d 100%)'
  },
  {
    icon: '📱',
    label: 'BUT I HAVE APPLE HEALTH',
    title: 'Apple Health stores data. This saves lives.',
    desc: 'Apple Health is designed for you. MedyCard Pro is designed for the EMT, the ER nurse, and the family member who needs information fast — under pressure, on any device.',
    highlight: "Most first responders don't know how to find Apple Health on a stranger's phone.",
    color: '#007AFF',
    bg: 'linear-gradient(160deg, #0a0f1a 0%, #0f2040 50%, #1d4ed8 100%)'
  },
  {
    icon: '👩‍⚕️',
    label: 'BUILT BY AN RN',
    title: 'Designed by a nurse with 30 years at the bedside',
    desc: 'Not a tech company guessing what matters. Every field, every alert, every feature was chosen by a Registered Nurse who has stood in an ER and needed this information.',
    highlight: 'Apple Health was built by engineers. This was built by a nurse.',
    color: '#34C759',
    bg: 'linear-gradient(160deg, #051a0d 0%, #0a3d1e 50%, #166534 100%)'
  },
  {
    icon: '👨‍👩‍👧',
    label: 'FOR YOUR WHOLE FAMILY',
    title: 'For seniors, caregivers, and families',
    desc: 'One spouse managing complex medications. An adult child caring for an aging parent across multiple doctors. Anyone whose medical history could matter in an emergency.',
    highlight: 'Works on any phone, any device, anywhere in the world. No app store required.',
    color: '#A855F7',
    bg: 'linear-gradient(160deg, #0f0a1a 0%, #2d1b5e 50%, #5b21b6 100%)'
  },
  {
    icon: '🔒',
    label: 'PRIVATE & SECURE',
    title: 'Your data never leaves your phone',
    desc: 'No accounts. No cloud. No subscription. Everything is stored only on your device, protected by your personal PIN. Nothing is ever sent to any server — ever.',
    highlight: 'In an emergency, first responders can access critical info without your PIN.',
    color: '#F59E0B',
    bg: 'linear-gradient(160deg, #1a1005 0%, #3d2a0a 50%, #92400e 100%)'
  },
  {
    icon: '✅',
    label: "YOU'RE READY",
    title: 'Set up takes less than 3 minutes',
    desc: 'Add your medications, allergies, emergency contacts, and insurance. Your Medical ID is instantly ready for any situation — at home, at the doctor, or anywhere in the world.',
    highlight: "Let's get started. The people who love you will be glad you did.",
    color: '#EF4444',
    bg: 'linear-gradient(160deg, #0f172a 0%, #1e3a5f 50%, #1d4ed8 100%)'
  }
];

const WelcomeModal = ({ onStart }: { onStart: () => void }) => {
  const [step, setStep] = useState(0);
  const s = ONBOARD_STEPS[step];
  const total = ONBOARD_STEPS.length;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[2000] flex flex-col justify-between overflow-y-auto p-6 md:p-12 text-white"
      style={{ background: s.bg }}
    >
      <div className="w-full max-w-xl mx-auto flex flex-col gap-4 mt-4 shrink-0">
        <div className="flex items-center justify-between">
          <div className="bg-white/10 border border-white/20 rounded-full px-4 py-1.5 backdrop-blur-md">
            <span className="text-[10px] md:text-xs font-black tracking-widest uppercase text-white/90">
              {s.label}
            </span>
          </div>
          <p className="text-xs font-bold text-white/60">{step + 1} of {total}</p>
        </div>

        <div className="flex gap-1.5 h-1">
          {ONBOARD_STEPS.map((_, idx) => (
            <div
              key={idx}
              className="flex-1 rounded-full transition-all duration-300"
              style={{
                backgroundColor: idx <= step ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.2)'
              }}
            />
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-center max-w-xl mx-auto w-full py-6 space-y-6">
        <div className="flex items-start">
          <div className="w-20 h-20 bg-white/10 border-2 border-white/25 rounded-3xl flex items-center justify-center text-4xl shadow-xl shadow-black/10 backdrop-blur-md shrink-0">
            <span>{s.icon}</span>
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-black tracking-tight leading-tight text-white drop-shadow-sm">
            {s.title}
          </h2>
          <p className="text-slate-100/90 text-base md:text-lg leading-relaxed font-medium">
            {s.desc}
          </p>
        </div>

        <div className="bg-white/10 border border-white/15 rounded-2xl p-4 md:p-6 backdrop-blur-sm shadow-sm space-y-2">
          <div className="flex gap-2 items-start">
            <span className="text-xl shrink-0 mt-0.5">💡</span>
            <span className="text-sm md:text-base font-semibold text-white/95 leading-relaxed">
              {s.highlight}
            </span>
          </div>
        </div>
      </div>

      <div className="w-full max-w-xl mx-auto flex flex-col gap-4 mb-4 shrink-0">
        <button
          onClick={() => {
            if (step < total - 1) {
              setStep(prev => prev + 1);
            } else {
              onStart();
            }
          }}
          className="w-full bg-white text-slate-900 py-4 rounded-2xl font-black text-base md:text-lg shadow-xl hover:bg-slate-100 transition-all active:scale-95 flex items-center justify-center gap-2"
        >
          <span>{step < total - 1 ? 'Continue  →' : 'Get Started — Set Up My PIN'}</span>
        </button>

        <div className="flex justify-between items-center text-sm font-bold">
          {step > 0 ? (
            <button
              onClick={() => setStep(prev => prev - 1)}
              className="text-white/60 hover:text-white transition-all px-2 py-1"
            >
              ← Back
            </button>
          ) : (
            <div />
          )}
          <button
            onClick={onStart}
            className="text-white/40 hover:text-white/80 font-semibold transition-all px-2 py-1"
          >
            Skip intro
          </button>
        </div>
      </div>
    </motion.div>
  );
};

const PasscodeLockScreen = ({ 
  correctPin, 
  onUnlock, 
  onEmergencyBypass 
}: { 
  correctPin: string; 
  onUnlock: () => void; 
  onEmergencyBypass: () => void;
}) => {
  const [enteredDigits, setEnteredDigits] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string>('');

  const handleDigitClick = (num: string) => {
    if (enteredDigits.length < 4) {
      const newVal = enteredDigits + num;
      setEnteredDigits(newVal);
      setErrorMsg('');

      if (newVal === correctPin) {
        setTimeout(() => {
          onUnlock();
          setEnteredDigits('');
        }, 150);
      } else if (newVal.length === 4) {
        setTimeout(() => {
          setErrorMsg('Incorrect Passcode');
          setEnteredDigits('');
        }, 300);
      }
    }
  };

  const handleDelete = () => {
    setEnteredDigits(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    setEnteredDigits('');
    setErrorMsg('');
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (/^[0-9]$/.test(e.key)) {
        handleDigitClick(e.key);
      } else if (e.key === 'Backspace') {
        handleDelete();
      } else if (e.key === 'Escape') {
        handleClear();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [enteredDigits, correctPin]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[1200] flex flex-col items-center justify-start sm:justify-center bg-slate-900/98 backdrop-blur-xl p-4 py-8 sm:py-12 text-slate-100 overflow-y-auto"
    >
      <div className="w-full max-w-md flex flex-col items-center space-y-8 text-center my-auto py-4">
        {/* MedyCard Logo */}
        <div className="flex flex-col items-center gap-2">
          <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-red-600/30">
            <ShieldCheck size={36} fill="currentColor" />
          </div>
          <h2 className="text-3xl font-black text-white tracking-tight">MedyCard Pro</h2>
          <p className="text-blue-400 font-bold text-xs uppercase tracking-widest leading-relaxed">Active Medical Guardian</p>
        </div>

        {/* Instructions */}
        <div className="space-y-2">
          <p className="text-slate-300 font-medium text-sm md:text-base">Enter personal access passcode to unlock vault</p>
          <p className="text-[10px] text-slate-500 font-mono tracking-widest">(Default Startup Code: {correctPin})</p>
        </div>

        {/* DOT Indicators */}
        <div className="flex justify-center gap-6 py-2">
          {[0, 1, 2, 3].map((index) => (
            <div
              key={index}
              className={cn(
                "w-4 h-4 rounded-full border-2 transition-all duration-300",
                index < enteredDigits.length 
                  ? "bg-blue-500 border-blue-400 scale-110 shadow-lg shadow-blue-500/50" 
                  : "border-slate-600"
              )}
            />
          ))}
        </div>

        {/* Error message */}
        <div className="h-4">
          {errorMsg && (
            <motion.p 
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-red-500 font-bold text-xs md:text-sm"
            >
              {errorMsg}
            </motion.p>
          )}
        </div>

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[280px] px-2">
          {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((num) => (
            <button
              key={num}
              onClick={() => handleDigitClick(num)}
              className="w-14 h-14 rounded-full bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-xl font-black text-slate-100 shadow-md hover:bg-slate-700 active:scale-95 transition-all mx-auto"
            >
              {num}
            </button>
          ))}
          <button
            onClick={handleClear}
            className="w-14 h-14 rounded-full flex items-center justify-center text-[10px] font-black tracking-wider text-slate-400 hover:text-white transition-all mx-auto active:scale-95"
          >
            CLEAR
          </button>
          <button
            onClick={() => handleDigitClick("0")}
            className="w-14 h-14 rounded-full bg-slate-800/80 border border-slate-700/50 flex items-center justify-center text-xl font-black text-slate-100 shadow-md hover:bg-slate-700 active:scale-95 transition-all mx-auto"
          >
            0
          </button>
          <button
            onClick={handleDelete}
            className="w-14 h-14 rounded-full flex items-center justify-center text-[10px] font-black tracking-wider text-slate-400 hover:text-white transition-all mx-auto active:scale-95"
          >
            DEL
          </button>
        </div>

        {/* EMERGENCY ACCESS SECTION FOR EMERGENCY WORKERS */}
        <div className="w-full pt-5 border-t border-slate-800 flex flex-col items-center space-y-2.5">
          <div className="flex items-center gap-1.5 text-red-500 bg-red-500/10 px-3 py-1 rounded-full border border-red-500/20">
            <AlertCircle size={12} className="animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-wider text-red-400">Paramedic / Emergency Responders</span>
          </div>

          <button
            onClick={onEmergencyBypass}
            className="w-full bg-red-600 hover:bg-red-700 text-white py-3 px-6 rounded-2xl font-black text-xs md:text-sm flex items-center justify-center gap-2.5 shadow-xl shadow-red-600/20 active:scale-95 transition-all animate-pulse"
          >
            <AlertCircle size={18} className="animate-bounce" />
            <span>🚑 FIRST RESPONDER BYPASS ACCESS</span>
          </button>
          <p className="text-[9px] text-slate-500 text-center leading-relaxed max-w-sm">
            Provides instant one-tap access to allergies, blood group, medications, and primary contacts without needing a security Passcode.
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default function App() {
  const [activePage, setActivePage] = useState<Page>('vault');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isFlashing, setIsFlashing] = useState(false);
  const [isUnmasked, setIsUnmasked] = useState(false);
  const [isTravelLock, setIsTravelLock] = useState(false);
  const [isSeniorMode, setIsSeniorMode] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState<string | null>(null);
  const [authenticatedRecords, setAuthenticatedRecords] = useState<Set<string>>(new Set());
  const [showWelcomeModal, setShowWelcomeModal] = useState(true);
  const [showEmergencyOverlay, setShowEmergencyOverlay] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [appPin, setAppPin] = useState(() => localStorage.getItem('medycard_pin') || '1234');
  const [passcodeFeedback, setPasscodeFeedback] = useState('');

  // Premium merged offline-first state extensions
  const [journal, setJournal] = useState<PainLog[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('medycard_journal') || '[]');
    } catch {
      return [];
    }
  });
  const [pendingPainLevel, setPendingPainLevel] = useState<number>(5);
  const [pendingLocation, setPendingLocation] = useState<string>('General');
  const [pendingNotes, setPendingNotes] = useState<string>('');
  const [showHealthCard, setShowHealthCard] = useState(false);
  const [insuranceCard, setInsuranceCard] = useState<string | null>(() => localStorage.getItem('medycard_insurance_card'));
  const [vaccinationCard, setVaccinationCard] = useState<string | null>(() => localStorage.getItem('medycard_vaccination_card'));
  const [safetyDocs, setSafetyDocs] = useState<any[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('medycard_docs') || '[]');
    } catch {
      return [];
    }
  });
  
  const emergencyHubRef = useRef<HTMLDivElement>(null);
  const mainScrollRef = useRef<HTMLDivElement>(null);
  
  // Vault Data State
  const [medications, setMedications] = useState<Medication[]>(() => {
    try {
      const stored = localStorage.getItem('medycard_medications');
      return stored ? JSON.parse(stored) : [
        { id: '1', name: 'Lisinopril', dosage: '10mg', frequency: 'Once daily', status: 'safe' }
      ];
    } catch {
      return [{ id: '1', name: 'Lisinopril', dosage: '10mg', frequency: 'Once daily', status: 'safe' }];
    }
  });
  const [caregiverLogs] = useState<CaregiverLog[]>([
    { id: '1', name: 'Jane Doe (Wife)', time: '2h ago', action: 'Viewed Medical ID' },
    { id: '2', name: 'Dr. Smith', time: '5h ago', action: 'Accessed Lab Reports' },
    { id: '3', name: 'Emergency Services (EMS)', time: '18h ago', action: 'Scanned NFC Card' }
  ]);
  const [medicalHistory, setMedicalHistory] = useState(() => {
    return localStorage.getItem('medycard_history') || 'No major surgeries. Controlled hypertension.';
  });
  const [allergies, setAllergies] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('medycard_allergies');
      return stored ? JSON.parse(stored) : ['Penicillin', 'Peanuts'];
    } catch {
      return ['Penicillin', 'Peanuts'];
    }
  });
  const [bloodType, setBloodType] = useState(() => {
    return localStorage.getItem('medycard_blood_type') || 'O Positive';
  });
  const [weight, setWeight] = useState(() => {
    return localStorage.getItem('medycard_weight') || '78 kg';
  });

  // Form States & Toggle Panels
  const [newMed, setNewMed] = useState({ name: '', dosage: '', frequency: '' });
  const [newAllergy, setNewAllergy] = useState('');
  
  const [showHowToAddInfo, setShowHowToAddInfo] = useState(false);
  const [showAddMedForm, setShowAddMedForm] = useState(false);
  const [showAddAllergyForm, setShowAddAllergyForm] = useState(false);
  const [showAppendHistoryForm, setShowAppendHistoryForm] = useState(false);
  const [newHistoryEvent, setNewHistoryEvent] = useState('');
  
  const [showAddVitalForm, setShowAddVitalForm] = useState(false);
  const [newVital, setNewVital] = useState({ label: '', value: '' });
  const [customVitals, setCustomVitals] = useState<{ id: string; label: string; value: string }[]>(() => {
    try {
      const stored = localStorage.getItem('medycard_custom_vitals');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Family State
  const [contacts, setContacts] = useState(() => {
    try {
      const stored = localStorage.getItem('medycard_contacts');
      return stored ? JSON.parse(stored) : [
        { id: '1', name: 'Jane Doe', relation: 'Wife', phone: '+1 (555) 012-3456' },
        { id: '2', name: 'Dr. Smith', relation: 'Primary Physician', phone: '+1 (555) 987-6543' }
      ];
    } catch {
      return [
        { id: '1', name: 'Jane Doe', relation: 'Wife', phone: '+1 (555) 012-3456' },
        { id: '2', name: 'Dr. Smith', relation: 'Primary Physician', phone: '+1 (555) 987-6543' }
      ];
    }
  });
  const [showAddContactForm, setShowAddContactForm] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', relation: '', phone: '' });

  // Med-Check State
  const [checkMeds, setCheckMeds] = useState<string[]>([]);
  const [riskStatus, setRiskStatus] = useState<'safe' | 'high' | 'none'>('none');

  // Lab Lens State
  const [isScanning, setIsScanning] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [labAnalysisResult, setLabAnalysisResult] = useState<string | null>(null);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [messages, setMessages] = useState<Record<Page, Message[]>>({
    emergency: [],
    vault: [],
    travel: [],
    family: [],
    lab: [],
    check: [],
    journal: []
  });
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => {
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  // Auto-lock timer effect (5 minutes idle lock)
  useEffect(() => {
    let lockTimer: NodeJS.Timeout;

    const resetLockTimer = () => {
      if (lockTimer) clearTimeout(lockTimer);
      if (isUnlocked) {
        lockTimer = setTimeout(() => {
          setIsUnlocked(false);
          setIsUnmasked(false);
          localStorage.setItem('mc_lastAccess', Date.now().toString());
        }, 5 * 60 * 1000); // 5 minutes
      }
    };

    const events = ['touchstart', 'click', 'keydown', 'scroll', 'mousedown'];
    events.forEach(e => window.addEventListener(e, resetLockTimer));

    resetLockTimer();

    return () => {
      if (lockTimer) clearTimeout(lockTimer);
      events.forEach(e => window.removeEventListener(e, resetLockTimer));
    };
  }, [isUnlocked]);

  const isPrivacyShieldActive = !isUnmasked && (isMobile || isTravelLock);

  const scrollToBottom = () => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      scrollToBottom();
    }, 100);
    return () => clearTimeout(timer);
  }, [messages[activePage]]);

  useEffect(() => {
    let active = true;
    let stream: MediaStream | null = null;

    if (isScanning && videoRef.current) {
      navigator.mediaDevices.getUserMedia({ video: true })
        .then(s => {
          if (active && videoRef.current) {
            stream = s;
            videoRef.current.srcObject = s;
          } else {
            s.getTracks().forEach(track => track.stop());
          }
        })
        .catch(err => console.error("Camera error:", err));
    }

    return () => {
      active = false;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
        videoRef.current.srcObject = null;
      }
    };
  }, [isScanning]);

  const checkInteractions = (meds: string[]) => {
    // Simple demo logic: Lisinopril + Aspirin or similar
    const dangerousPairs = [
      ['lisinopril', 'aspirin'],
      ['warfarin', 'ibuprofen'],
      ['metformin', 'contrast dye']
    ];
    
    if (meds.length < 2) return 'none';
    
    const lowerMeds = meds.map(m => m.toLowerCase());
    for (const [m1, m2] of dangerousPairs) {
      if (lowerMeds.includes(m1) && lowerMeds.includes(m2)) return 'high';
    }
    return 'safe';
  };

  useEffect(() => {
    setRiskStatus(checkInteractions(checkMeds));
  }, [checkMeds]);

  useEffect(() => {
    let timer1: NodeJS.Timeout;
    let timer2: NodeJS.Timeout;

    if (showEmergencyOverlay) {
      setIsUnmasked(true);
      timer1 = setTimeout(() => {
        if (emergencyHubRef.current) {
          emergencyHubRef.current.scrollIntoView({ behavior: 'smooth' });
        }
        setIsFlashing(true);
        timer2 = setTimeout(() => setIsFlashing(false), 3000);
      }, 100);
    }

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [showEmergencyOverlay]);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isAuthenticating) {
      timer = setTimeout(() => {
        setAuthenticatedRecords(prev => new Set(prev).add(isAuthenticating));
        setIsAuthenticating(null);
      }, 1500);
    }
    return () => clearTimeout(timer);
  }, [isAuthenticating]);

  useEffect(() => {
    localStorage.setItem('medycard_medications', JSON.stringify(medications));
  }, [medications]);

  useEffect(() => {
    localStorage.setItem('medycard_history', medicalHistory);
  }, [medicalHistory]);

  useEffect(() => {
    localStorage.setItem('medycard_allergies', JSON.stringify(allergies));
  }, [allergies]);

  useEffect(() => {
    localStorage.setItem('medycard_blood_type', bloodType);
  }, [bloodType]);

  useEffect(() => {
    localStorage.setItem('medycard_weight', weight);
  }, [weight]);

  useEffect(() => {
    localStorage.setItem('medycard_contacts', JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem('medycard_custom_vitals', JSON.stringify(customVitals));
  }, [customVitals]);

  const handleExportPDF = async () => {
    const element = document.getElementById('emergency-blueprint');
    if (!element) return;
    
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff'
    });
    
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    const imgProps = pdf.getImageProperties(imgData);
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save(`MedyCard_Pro_Clinical_Summary_${new Date().toISOString().split('T')[0]}.pdf`);
  };

  const handleAddMedication = () => {
    if (newMed.name) {
      const existingNames = medications.map(m => m.name);
      const risk = checkInteractions([...existingNames, newMed.name]);
      const status = risk === 'high' ? 'caution' : 'safe';
      
      setMedications(prev => [...prev, { ...newMed, id: Date.now().toString(), status }]);
      setNewMed({ name: '', dosage: '', frequency: '' });
    }
  };

  const handleFileUpload = async (file: File) => {
    if (!file) return;
    setUploadedFile(file);
    setIsAnalyzing(true);
    setLabAnalysisResult(null);

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64Data = (reader.result as string).split(',')[1];
        const result = await analyzeLabReport(base64Data, file.type);
        setLabAnalysisResult(result || "Analysis failed.");
        setIsAnalyzing(false);
      };
      reader.readAsDataURL(file);
    } catch (error) {
      console.error("Analysis error:", error);
      setLabAnalysisResult("An error occurred during analysis.");
      setIsAnalyzing(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && (file.type.startsWith('image/') || file.type === 'application/pdf')) {
      handleFileUpload(file);
    }
  };
  const handleEmergencyAccess = () => {
    setShowEmergencyOverlay(true);
  };

  const handleViewRecord = (id: string) => {
    if (isUnmasked) return;
    if (authenticatedRecords.has(id)) return;

    setIsAuthenticating(id);
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: input };
    setMessages(prev => ({ ...prev, [activePage]: [...prev[activePage], userMsg] }));
    const currentInput = input;
    setInput('');
    setIsLoading(true);

    try {
      const result = await askMedy(currentInput, activePage);
      const aiMsg: Message = { 
        id: (Date.now() + 1).toString(), 
        role: 'ai', 
        content: result.text || "I'm sorry, I couldn't process that.",
        sources: result.sources
      };
      setMessages(prev => ({ ...prev, [activePage]: [...prev[activePage], aiMsg] }));
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const NavItem = ({ id, icon: Icon, label }: { id: Page, icon: any, label: string }) => (
    <button
      onClick={() => {
        if (id === 'emergency') {
          setShowEmergencyOverlay(true);
        } else {
          setActivePage(id);
        }
        setIsSidebarOpen(false);
      }}
      className={cn(
        "flex items-center gap-3 w-full px-4 py-3 rounded-xl transition-all font-medium",
        (activePage === id && id !== 'emergency') || (id === 'emergency' && showEmergencyOverlay)
          ? "bg-navy text-white shadow-lg shadow-navy/20" 
          : "text-slate-600 hover:bg-slate-100"
      )}
    >
      <Icon size={20} />
      <span>{label}</span>
    </button>
  );

  return (
    <div className="flex h-screen bg-slate-800 text-slate-100 overflow-hidden bg-dots">
      {/* Welcome Modal */}
      <AnimatePresence>
        {showWelcomeModal && (
          <WelcomeModal onStart={() => setShowWelcomeModal(false)} />
        )}
      </AnimatePresence>

      {/* Passcode Lock Screen */}
      <AnimatePresence>
        {!isUnlocked && !showWelcomeModal && (
          <PasscodeLockScreen 
            correctPin={appPin} 
            onUnlock={() => setIsUnlocked(true)} 
            onEmergencyBypass={() => {
              setShowEmergencyOverlay(true);
              setIsUnmasked(true);
            }} 
          />
        )}
      </AnimatePresence>

      {/* Auth Overlay */}
      <AnimatePresence>
        {isAuthenticating && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[1000] flex items-center justify-center bg-slate-800/90 backdrop-blur-sm"
          >
            <div className="text-center space-y-6">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                className="inline-block p-4 bg-blue-500/20 rounded-full border border-blue-500/30"
              >
                <Lock className="text-blue-400 w-12 h-12" />
              </motion.div>
              <div className="space-y-2">
                <h3 className="text-xl font-black text-white tracking-tight">Authenticating Secure Connection...</h3>
                <p className="text-blue-400/60 text-sm font-mono uppercase tracking-widest">MedyCard Pro Protocol v4.2</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Sidebar (Desktop) */}
      <aside className="hidden lg:flex flex-col w-64 bg-slate-100 border-r-2 border-slate-300 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 bg-medy-red rounded-xl flex items-center justify-center text-white shadow-lg shadow-medy-red/25 shrink-0">
            <CreditCard size={26} />
          </div>
          <h1 className="text-2xl lg:text-[28px] font-black tracking-tight text-slate-900 leading-none">MedyCard Pro</h1>
        </div>

        {/* Status Widget (Moved Up as Requested) */}
        <div className="mb-6 p-4 bg-slate-200/50 rounded-2xl border-2 border-slate-300 flex flex-col gap-3">
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5">Status</p>
            <div className="flex items-center gap-2 text-emerald-600">
              <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              <span className="text-xs font-semibold">System Protected</span>
            </div>
          </div>
          {isUnlocked && (
            <button
              onClick={() => {
                setIsUnlocked(false);
                setIsUnmasked(false);
              }}
              className="w-full bg-slate-800 hover:bg-slate-900 text-white font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-slate-900/10 cursor-pointer mt-0.5 animate-none"
            >
              <Lock size={12} />
              <span>Lock Application</span>
            </button>
          )}
          <button
            onClick={() => setShowWelcomeModal(true)}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-blue-500/10 cursor-pointer text-center"
          >
            <HelpCircle size={12} />
            <span>Show App Info</span>
          </button>
        </div>

        <nav className="space-y-2 flex-1">
          <NavItem id="emergency" icon={AlertCircle} label="Emergency Hub" />
          <NavItem id="vault" icon={ShieldCheck} label="Secure Vault" />
          <NavItem id="journal" icon={Activity} label="Pain Journal" />
          <NavItem id="family" icon={Users} label="Family" />
          <NavItem id="lab" icon={Camera} label="Lab Lens" />
          <NavItem id="check" icon={Stethoscope} label="Med-Check" />
          <NavItem id="travel" icon={Globe} label="Travel Guard" />
        </nav>

        <div className="mt-auto pt-4 border-t border-slate-200">
          {isUnlocked && (
            <button
              onClick={() => setShowEmergencyOverlay(true)}
              className="w-full bg-red-650 hover:bg-red-700 text-white font-black text-xs py-3 px-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg shadow-red-500/20 cursor-pointer animate-pulse"
            >
              <AlertCircle size={14} />
              <span>EMERGENCY INFO</span>
            </button>
          )}
        </div>
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 bg-slate-100/95 backdrop-blur-md border-b border-slate-300 z-50 px-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-medy-red rounded-lg flex items-center justify-center text-white shadow-sm shrink-0">
            <CreditCard size={20} />
          </div>
          <span className="font-black text-slate-900 text-lg tracking-tight">MedyCard Pro</span>
        </div>
        <div className="flex items-center gap-2">
          {isUnlocked && (
            <button
              onClick={() => setShowEmergencyOverlay(true)}
              className="px-2.5 py-1.5 bg-red-650 hover:bg-red-700 active:bg-red-800 text-white rounded-lg text-xs font-black transition-all flex items-center gap-1 cursor-pointer animate-pulse shrink-0 shadow-md mr-1"
              title="Emergency Info"
            >
              <AlertCircle size={14} />
              <span>SOS</span>
            </button>
          )}
          <div className="hidden sm:flex px-2 py-1 bg-emerald-100/60 border border-emerald-200 rounded-md items-center gap-1">
            <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-[10px] font-bold text-emerald-800 uppercase">Secure</span>
          </div>
          {isUnlocked && (
            <button
              onClick={() => {
                setIsUnlocked(false);
                setIsUnmasked(false);
              }}
              className="p-1.5 bg-slate-200 hover:bg-slate-300 active:bg-slate-400 text-slate-700 rounded-lg transition-all flex items-center justify-center cursor-pointer border border-slate-300/60"
              title="Lock App"
            >
              <Lock size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-navy/40 backdrop-blur-sm z-[60] md:hidden"
            />
            <motion.aside 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              className="fixed top-0 left-0 bottom-0 w-72 bg-slate-100 z-[70] p-6 md:hidden shadow-2xl"
            >
              <div className="flex items-center justify-between mb-10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-medy-red rounded-xl flex items-center justify-center text-white">
                    <CreditCard size={24} />
                  </div>
                  <h1 className="text-xl font-black text-slate-900">MedyCard Pro</h1>
                </div>
                <button onClick={() => setIsSidebarOpen(false)} className="text-slate-400">
                  <X size={24} />
                </button>
              </div>
              <nav className="space-y-2 mb-8">
                <NavItem id="emergency" icon={AlertCircle} label="Emergency Hub" />
                <NavItem id="vault" icon={ShieldCheck} label="Secure Vault" />
                <NavItem id="journal" icon={Activity} label="Pain Journal" />
                <NavItem id="family" icon={Users} label="Family" />
                <NavItem id="lab" icon={Camera} label="Lab Lens" />
                <NavItem id="check" icon={Stethoscope} label="Med-Check" />
                <NavItem id="travel" icon={Globe} label="Travel Guard" />
              </nav>
              <div className="pt-4 border-t border-slate-200">
                <button
                  onClick={() => {
                    setShowWelcomeModal(true);
                    setIsSidebarOpen(false);
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-black text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md shadow-blue-500/10 cursor-pointer"
                >
                  <HelpCircle size={14} />
                  <span>Show App Info</span>
                </button>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 flex flex-col pt-16 lg:pt-6 relative overflow-y-auto items-center px-4">
        {/* 1. System Bar (Top) - Desktop Only */}
        <div className="hidden lg:flex justify-between items-center w-full px-4 mt-2 mb-4 max-w-4xl mx-auto gap-6">
          <div className="flex-1 flex items-center justify-between bg-white/10 backdrop-blur-md px-6 py-3.5 rounded-3xl border border-white/20 shadow-lg">
            <span className="text-sm font-black text-blue-300 uppercase tracking-widest">Senior Mode</span>
            <button 
              onClick={() => setIsSeniorMode(!isSeniorMode)}
              className={cn(
                "w-14 h-8 rounded-full transition-all relative cursor-pointer border-2 border-slate-700/50 shadow-inner",
                isSeniorMode ? "bg-blue-600" : "bg-slate-700"
              )}
              title="Toggle Large Fonts & Layouts"
            >
              <div className={cn(
                "absolute top-0.5 w-6 h-6 bg-white rounded-full transition-all shadow-md flex items-center justify-center",
                isSeniorMode ? "left-[28px]" : "left-0.5"
              )} />
            </button>
          </div>

          <div className="flex-1 flex items-center justify-between bg-white/10 backdrop-blur-md px-6 py-3.5 rounded-3xl border border-white/20 shadow-lg">
            <span className="text-sm font-black text-red-400 uppercase tracking-widest">Travel Lock</span>
            <button 
              onClick={() => setIsTravelLock(!isTravelLock)}
              className={cn(
                "w-14 h-8 rounded-full transition-all relative cursor-pointer border-2 border-slate-700/50 shadow-inner",
                isTravelLock ? "bg-blue-600" : "bg-slate-700"
              )}
              title="Secure Local Storage from Scans"
            >
              <div className={cn(
                "absolute top-0.5 w-6 h-6 bg-white rounded-full transition-all shadow-md",
                isTravelLock ? "left-[28px]" : "left-0.5"
              )} />
            </button>
          </div>
        </div>

        {/* 2. Header: Branding - Desktop Only */}
        <div className="hidden lg:flex w-full px-4 py-2 flex flex-col items-center text-center max-w-4xl mx-auto">
          <div className="flex items-center gap-2 mb-0.5">
            <h1 className={cn(
              "text-xl md:text-2xl font-black tracking-tight text-slate-100 transition-all",
              isSeniorMode && "text-white scale-105"
            )}>
              MedyCard <span className="text-[8px] bg-blue-600 text-white px-1.5 py-0.5 rounded uppercase tracking-widest font-bold align-middle ml-0.5">Pro</span>
            </h1>
            <div className="w-5 h-5 bg-red-600 rounded flex items-center justify-center text-white shadow-md">
              <ShieldCheck fill="currentColor" className="text-white w-3 h-3" />
            </div>
          </div>
          <p className={cn(
            "text-blue-400 font-light text-[9px] tracking-[0.2em] uppercase transition-all",
            isSeniorMode && "text-blue-300 font-bold"
          )}>Active Medical Guardian</p>
        </div>


        <div ref={mainScrollRef} className="flex-1 overflow-y-auto scrollbar-hide w-full">
          <div className="h-full max-w-4xl mx-auto w-full px-4 md:px-6 pb-24 lg:pb-10">
            <div className="bg-slate-800 md:rounded-[2rem] overflow-hidden relative min-h-full">
              {/* 3. Emergency Zone (The Priority) - Compact */}
              <div className="w-full max-w-4xl mx-auto">
                <button 
                  onClick={handleEmergencyAccess}
                  className="w-full bg-red-600 py-3.5 px-4 flex items-center justify-center animate-pulse hover:bg-red-700 transition-colors cursor-pointer group relative overflow-hidden"
                >
                  <div className="absolute inset-0 bg-white/10 animate-[shimmer_2s_infinite]" />
                  <span className="text-white font-black text-sm sm:text-base tracking-[0.15em] uppercase relative z-10 text-center flex items-center gap-2">
                    PARAMEDICS / EMERGENCY RESPONDERS
                  </span>
                </button>

                {/* 4. Action Zone - Tight Grid */}
                <div className="w-full p-3">
                  <div className="grid grid-cols-3 gap-2">
                    <button className="w-full card flex flex-col items-center justify-center gap-1 p-2 text-slate-900 shadow-md rounded-xl active:scale-95 transition-all min-h-[70px] border-2 border-blue-100">
                      <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center shrink-0 shadow-sm">
                        <Nfc size={20} />
                      </div>
                      <p className={cn(
                        "font-bold uppercase tracking-widest text-center leading-tight",
                        isSeniorMode ? "text-sm" : "text-[8px]"
                      )}>SCAN CARD</p>
                    </button>
                    <button className="w-full card flex flex-col items-center justify-center gap-1 p-2 text-slate-900 shadow-md rounded-xl active:scale-95 transition-all min-h-[70px] border-2 border-red-100">
                      <div className="w-8 h-8 bg-red-50 text-red-600 rounded-lg flex items-center justify-center shrink-0 shadow-sm">
                        <MapPin size={20} />
                      </div>
                      <p className={cn(
                        "font-bold uppercase tracking-widest text-center leading-tight",
                        isSeniorMode ? "text-sm" : "text-[8px]"
                      )}>FAMILY ALERT</p>
                    </button>
                    <button 
                      onClick={() => setIsChatOpen(!isChatOpen)}
                      className="w-full card flex flex-col items-center justify-center gap-1 p-2 text-slate-900 shadow-md rounded-xl active:scale-95 transition-all min-h-[70px] border-2 border-blue-100"
                    >
                      <div className="w-8 h-8 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center shrink-0 shadow-sm">
                        <MessageCircle size={20} />
                      </div>
                      <p className={cn(
                        "font-bold uppercase tracking-widest text-center leading-tight",
                        isSeniorMode ? "text-sm" : "text-[8px]"
                      )}>ASK MEDY AI</p>
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex fixed md:absolute bottom-24 md:bottom-6 right-6 z-[100] pointer-events-auto">
                <AnimatePresence>
                  {isChatOpen && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8, y: 40, x: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0, x: 0 }}
                      exit={{ opacity: 0, scale: 0.8, y: 40, x: 20 }}
                      className="absolute bottom-16 right-0 w-[calc(100vw-3rem)] md:w-80 bg-slate-50 rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.2)] border border-slate-200 overflow-hidden flex flex-col"
                    >
                      <div className="bg-navy p-4 text-white flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-white/10 rounded-lg flex items-center justify-center">
                            <Activity size={14} className="text-medy-red" />
                          </div>
                          <div>
                            <p className="font-bold text-xs">First Aid Assistant</p>
                            <p className="text-[8px] text-blue-200 font-medium">Always here to help</p>
                          </div>
                        </div>
                        <button onClick={() => setIsChatOpen(false)} className="w-6 h-6 rounded-full hover:bg-white/10 flex items-center justify-center transition-colors">
                          <X size={16} />
                        </button>
                      </div>
                      <div className="h-[300px] overflow-y-auto p-4 space-y-3 scrollbar-hide bg-slate-100">
                        {messages.emergency.length === 0 && (
                          <div className="h-full flex flex-col items-center justify-center text-center p-4 opacity-40">
                            <MessageCircle size={32} className="mb-2 text-slate-900" />
                            <p className="text-xs font-bold text-slate-900">How can I assist?</p>
                          </div>
                        )}
                        {messages.emergency.map(msg => (
                          <div key={msg.id} className={cn("flex", msg.role === 'user' ? "justify-end" : "justify-start")}>
                            <div className={cn(
                              "max-w-[90%] p-3 rounded-xl text-xs shadow-sm",
                              msg.role === 'user' ? "bg-navy text-white rounded-tr-none" : "bg-slate-50 border-2 border-slate-300 text-slate-900 rounded-tl-none"
                            )}>
                              <Markdown>{msg.content}</Markdown>
                            </div>
                          </div>
                        ))}
                        {isLoading && (
                          <div className="flex justify-start">
                            <div className="bg-slate-50 border-2 border-slate-300 p-3 rounded-xl rounded-tl-none shadow-sm">
                              <Loader2 size={14} className="animate-spin text-slate-900" />
                            </div>
                          </div>
                        )}
                        <div ref={chatEndRef} />
                      </div>
                      <div className="p-4 border-t-2 border-slate-300 bg-slate-50 flex gap-2">
                        <input 
                          type="text" 
                          value={input}
                          onChange={e => setInput(e.target.value)}
                          onKeyDown={e => e.key === 'Enter' && handleSend()}
                          placeholder="Ask anything..."
                          className="flex-1 bg-slate-100 border-2 border-slate-300 rounded-xl px-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-navy/10 transition-all"
                        />
                        <button onClick={handleSend} className="w-10 h-10 bg-navy text-white rounded-xl shadow-lg shadow-navy/20 flex items-center justify-center hover:bg-navy/90 transition-all active:scale-95 flex-shrink-0">
                          <Send size={16} />
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <AnimatePresence mode="wait">
                {activePage === 'vault' && (
                <motion.div 
                  key="vault"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="space-y-8 p-4 md:p-6 w-full"
                >
                  <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-3xl font-black text-slate-100">Secure Vault</h2>
                      <p className="text-blue-400 text-sm">Your encrypted medical record repository.</p>
                    </div>
                    <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-100 font-bold shrink-0 shadow-sm">
                      <ShieldCheck size={16} />
                      <span className="text-xs">End-to-End Encrypted</span>
                    </div>
                  </header>

                   {/* Onboarding Guide Callout: "How to Add info" Dropdown */}
                   <div className="bg-gradient-to-r from-blue-900/40 to-indigo-900/40 border border-blue-500/30 rounded-[1.5rem] shadow-md overflow-hidden text-left">
                     <button 
                       onClick={() => setShowHowToAddInfo(!showHowToAddInfo)}
                       className="w-full px-5 py-4 flex items-center justify-between gap-3 text-sm font-black text-blue-200 uppercase tracking-wider cursor-pointer hover:bg-white/5 transition-all text-left"
                     >
                       <span className="flex items-center gap-2">
                         <HelpCircle size={18} className="text-blue-400" />
                         How do I add or manage my medical info?
                       </span>
                       <span className="text-blue-400 font-extrabold text-xs transition-transform duration-200">
                         {showHowToAddInfo ? "▲" : "▼"}
                       </span>
                     </button>
                     {showHowToAddInfo && (
                       <div className="px-5 pb-5 pt-1 border-t border-blue-500/15 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-xs text-slate-200 font-medium">
                         <div className="flex items-start gap-2">
                           <div className="w-5 h-5 bg-blue-500/20 text-blue-300 rounded flex items-center justify-center shrink-0 font-bold text-[10px] mt-0.5">1</div>
                           <p><strong>Add/Edit Vitals:</strong> Edit <span className="text-blue-300">Vital Essentials</span> below directly, or click the <span className="text-blue-400 font-extrabold">+</span> icon to register custom records.</p>
                         </div>
                         <div className="flex items-start gap-2">
                           <div className="w-5 h-5 bg-blue-500/20 text-blue-300 rounded flex items-center justify-center shrink-0 font-bold text-[10px] mt-0.5">2</div>
                           <p><strong>List Medications:</strong> Click the <span className="text-blue-400 font-extrabold">+</span> icon on Medications, enter details, and save.</p>
                         </div>
                         <div className="flex items-start gap-2">
                           <div className="w-5 h-5 bg-blue-500/20 text-blue-300 rounded flex items-center justify-center shrink-0 font-bold text-[10px] mt-0.5">3</div>
                           <p><strong>Manage Responders:</strong> Head over to the <span className="text-blue-300">Family</span> tab and click the <span className="text-blue-300 font-extrabold">+</span> to add emergency care partners.</p>
                         </div>
                         <div className="flex items-start gap-2">
                           <div className="w-5 h-5 bg-blue-500/20 text-blue-300 rounded flex items-center justify-center shrink-0 font-bold text-[10px] mt-0.5">4</div>
                           <p><strong>Security PIN:</strong> Change your lock passcode by typing a custom 4-digit code in the <span className="text-blue-300">Passcode Security</span> section at the bottom.</p>
                         </div>
                       </div>
                     )}
                   </div>

                  <div className="bg-slate-100/90 border-2 border-slate-300/60 p-6 rounded-[2rem] flex flex-col md:flex-row items-center justify-between gap-6 shadow-md text-slate-900">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-red-100 text-red-650 rounded-2xl flex items-center justify-center shadow-inner shrink-0 leading-none">
                        <CreditCard size={24} />
                      </div>
                      <div className="text-left">
                        <h3 className="font-extrabold text-[10px] uppercase tracking-wider text-slate-405">Digital Health ID Wallet</h3>
                        <h4 className="font-black text-xl text-slate-900 leading-tight">View My Digital Health Card</h4>
                        <p className="text-xs text-slate-500 mt-1 leading-relaxed">Present this high-fidelity card to EMS or first responders with one tap.</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowHealthCard(true)}
                      className="px-6 py-3.5 bg-rose-600 text-white font-black rounded-xl hover:bg-rose-700 active:scale-95 transition-all text-xs tracking-wider uppercase shadow-lg shadow-rose-600/25 cursor-pointer shrink-0"
                    >
                      Present My Card
                    </button>
                  </div>

                  {/* Vitals Profile Section */}
                  <section className="space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2">
                        <Heart size={20} className="text-red-500 fill-red-400" />
                        <h3 className="text-xl font-bold text-slate-800">Vital Essentials</h3>
                      </div>
                      <button 
                        onClick={() => setShowAddVitalForm(!showAddVitalForm)}
                        className="p-1.5 bg-blue-50 hover:bg-blue-100 hover:scale-105 active:scale-95 text-blue-600 rounded-full border border-blue-200 transition-all cursor-pointer"
                        title="Add Custom Vital Field"
                      >
                        <Plus size={18} />
                      </button>
                    </div>
                    
                    <div className="card w-full max-w-lg lg:max-w-none mx-auto p-6 rounded-[2rem] text-slate-900 bg-slate-100/90 border-2 border-slate-300/60 shadow-md">
                      <p className="text-xs text-slate-600 mb-4 font-semibold leading-relaxed">
                        These vitals are loaded onto your high-fidelity Digital Medical ID to inform emergency responders instantly.
                      </p>
                      
                      {showAddVitalForm && (
                        <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-200 mb-6 text-left space-y-3">
                          <p className="text-xs font-black text-blue-900 uppercase">Add New Custom Vital Detail</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black text-slate-500 uppercase">Vital Parameter Name</label>
                              <input 
                                type="text"
                                placeholder="e.g. Heart Rate, Height, Temp"
                                value={newVital.label}
                                onChange={e => setNewVital(prev => ({ ...prev, label: e.target.value }))}
                                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                              />
                            </div>
                            <div className="space-y-1.5">
                              <label className="text-[10px] font-black text-slate-500 uppercase">Measurement Value</label>
                              <input 
                                type="text"
                                placeholder="e.g. 72 bpm, 180 cm, 98.6 F"
                                value={newVital.value}
                                onChange={e => setNewVital(prev => ({ ...prev, value: e.target.value }))}
                                className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                              />
                            </div>
                          </div>
                          <div className="flex gap-2 justify-end pt-1">
                            <button
                              onClick={() => {
                                if (newVital.label && newVital.value) {
                                  setCustomVitals(prev => [...prev, {
                                    id: Date.now().toString(),
                                    label: newVital.label,
                                    value: newVital.value
                                  }]);
                                  setNewVital({ label: '', value: '' });
                                  setShowAddVitalForm(false);
                                } else {
                                  alert("Please fill up both Vital Name and Value");
                                }
                              }}
                              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black rounded-xl cursor-pointer transition-all shadow"
                            >
                              Add Parameter
                            </button>
                            <button
                              onClick={() => {
                                setNewVital({ label: '', value: '' });
                                setShowAddVitalForm(false);
                              }}
                              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-black rounded-xl cursor-pointer transition-all"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="space-y-1.5 text-left">
                          <label className="text-xs font-bold text-blue-900 uppercase block">Blood Type</label>
                          <select 
                            value={bloodType}
                            onChange={e => setBloodType(e.target.value)}
                            className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2 text-sm text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-red-500/20 cursor-pointer"
                          >
                            <option value="A Positive">A Positive (A+)</option>
                            <option value="A Negative">A Negative (A-)</option>
                            <option value="B Positive">B Positive (B+)</option>
                            <option value="B Negative">B Negative (B-)</option>
                            <option value="AB Positive">AB Positive (AB+)</option>
                            <option value="AB Negative">AB Negative (AB-)</option>
                            <option value="O Positive">O Positive (O+)</option>
                            <option value="O Negative">O Negative (O-)</option>
                            <option value="Unknown">Unknown</option>
                          </select>
                        </div>

                        <div className="space-y-1.5 text-left">
                          <label className="text-xs font-bold text-blue-900 uppercase block">Body Weight</label>
                          <input 
                            type="text" 
                            value={weight}
                            onChange={e => setWeight(e.target.value)}
                            placeholder="e.g. 78 kg or 170 lbs"
                            className="w-full bg-white border-2 border-slate-300 rounded-xl px-4 py-2 text-sm text-slate-905 font-bold focus:outline-none focus:ring-2 focus:ring-red-500/20"
                          />
                        </div>
                      </div>

                      {customVitals.length > 0 && (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6 pt-6 border-t border-slate-200">
                          {customVitals.map(v => (
                            <div key={v.id} className="flex justify-between items-center p-3.5 bg-white border border-slate-200 rounded-2xl shadow-sm">
                              <div className="text-left">
                                <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider block leading-none mb-1">{v.label}</label>
                                <span className="text-sm font-black text-slate-900">{v.value}</span>
                              </div>
                              <button 
                                onClick={() => setCustomVitals(prev => prev.filter(item => item.id !== v.id))}
                                className="text-slate-400 hover:text-red-600 p-1.5 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
                                title="Remove parameter"
                              >
                                <Trash2 size={14} />
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </section>

                  {/* Medications Section */}
                  <section className="space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2">
                        <Activity size={20} className="text-medy-red" />
                        <h3 className="text-xl font-bold text-slate-800">Medications</h3>
                      </div>
                      <button 
                        onClick={() => setShowAddMedForm(!showAddMedForm)}
                        className="p-1.5 bg-blue-50 hover:bg-blue-100 hover:scale-105 active:scale-95 text-blue-600 rounded-full border border-blue-200 transition-all cursor-pointer"
                        title="Add Medication Detail"
                      >
                        <Plus size={18} />
                      </button>
                    </div>

                    <div className="card w-full max-w-lg lg:max-w-none mx-auto space-y-4 mb-4">
                      {showAddMedForm ? (
                        <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-100 space-y-4">
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                            <div className="space-y-1">
                              <label className="text-xs font-bold text-blue-900 uppercase">Name</label>
                              <input 
                                type="text" 
                                placeholder="e.g. Lisinopril"
                                value={newMed.name}
                                onChange={e => setNewMed(prev => ({ ...prev, name: e.target.value }))}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 font-bold"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-xs font-bold text-blue-900 uppercase">Dosage</label>
                              <input 
                                type="text" 
                                placeholder="e.g. 10mg"
                                value={newMed.dosage}
                                onChange={e => setNewMed(prev => ({ ...prev, dosage: e.target.value }))}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 font-bold"
                              />
                            </div>
                            <div className="space-y-1">
                              <label className="text-xs font-bold text-blue-900 uppercase">Frequency</label>
                              <input 
                                type="text" 
                                placeholder="e.g. Once daily"
                                value={newMed.frequency}
                                onChange={e => setNewMed(prev => ({ ...prev, frequency: e.target.value }))}
                                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 font-bold"
                              />
                            </div>
                          </div>
                          <div className="flex gap-2 justify-end">
                            <button 
                              onClick={() => {
                                handleAddMedication();
                                setShowAddMedForm(false);
                              }}
                              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl cursor-pointer transition-all shadow"
                            >
                              Save Medication
                            </button>
                            <button 
                              onClick={() => {
                                setNewMed({ name: '', dosage: '', frequency: '' });
                                setShowAddMedForm(false);
                              }}
                              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer transition-all"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setShowAddMedForm(true)}
                          className="w-full py-4 border-2 border-dashed border-slate-300 hover:border-blue-400 hover:bg-blue-50/10 rounded-2xl flex items-center justify-center gap-2 text-slate-500 hover:text-blue-600 font-bold text-xs transition-all cursor-pointer"
                        >
                          <Plus size={16} />
                          <span>Add Medication</span>
                        </button>
                      )}

                      <div className="space-y-2 mt-4">
                        {medications.map(med => (
                          <div key={med.id} className="flex flex-col md:flex-row items-start md:items-center justify-between p-3 bg-slate-100 rounded-xl border border-slate-200 gap-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-bold text-sm">{med.name}</p>
                                {med.status === 'safe' ? (
                                  <span className="text-[8px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded-full border border-emerald-100">Verified Safe</span>
                                ) : med.status === 'caution' ? (
                                  <span className="text-[8px] font-bold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded-full border border-amber-100">Caution: Consult Doctor</span>
                                ) : null}
                              </div>
                              <p className="text-xs text-slate-500">{med.dosage} • {med.frequency}</p>
                            </div>
                            <button 
                              onClick={() => setMedications(prev => prev.filter(m => m.id !== med.id))}
                              className="text-slate-300 hover:text-medy-red transition-colors"
                            >
                              <X size={16} />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </section>

                  {/* Medical History Section */}
                  <section className="space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2">
                        <FileText size={20} className="text-slate-900" />
                        <h3 className="text-xl font-bold text-slate-800">Medical History</h3>
                      </div>
                      <button 
                        onClick={() => setShowAppendHistoryForm(!showAppendHistoryForm)}
                        className="p-1.5 bg-blue-50 hover:bg-blue-100 hover:scale-105 active:scale-95 text-blue-600 rounded-full border border-blue-200 transition-all cursor-pointer"
                        title="Quick Append History Item"
                      >
                        <Plus size={18} />
                      </button>
                    </div>

                    <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 p-5 space-y-4">
                      {showAppendHistoryForm && (
                        <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-200 text-slate-900 text-left space-y-2.5">
                          <p className="text-xs font-black text-blue-900 uppercase">Quick Add History Record</p>
                          <div className="flex flex-col sm:flex-row gap-2">
                            <input 
                              type="text" 
                              placeholder="e.g. Appendectomy (2018), or Diabetes Type II"
                              value={newHistoryEvent}
                              onChange={e => setNewHistoryEvent(e.target.value)}
                              onKeyDown={e => {
                                if (e.key === 'Enter' && newHistoryEvent) {
                                  setMedicalHistory(prev => prev ? `${prev}\n- ${newHistoryEvent}` : `- ${newHistoryEvent}`);
                                  setNewHistoryEvent('');
                                  setShowAppendHistoryForm(false);
                                }
                              }}
                              className="flex-1 bg-white border border-slate-300 rounded-xl px-4 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/20 text-slate-900"
                            />
                            <button
                              onClick={() => {
                                if (newHistoryEvent) {
                                  setMedicalHistory(prev => prev ? `${prev}\n- ${newHistoryEvent}` : `- ${newHistoryEvent}`);
                                  setNewHistoryEvent('');
                                  setShowAppendHistoryForm(false);
                                }
                              }}
                              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl cursor-pointer transition-all shrink-0"
                            >
                              Add Item
                            </button>
                          </div>
                          <p className="text-[10px] text-slate-500 italic">This will append a new line to the record below instantly.</p>
                        </div>
                      )}

                      <div className="space-y-1.5 text-left">
                        <label className="text-xs font-bold text-blue-905 uppercase block mb-1">Surgeries & Chronic Conditions</label>
                        <textarea 
                          rows={4}
                          value={medicalHistory}
                          onChange={e => setMedicalHistory(e.target.value)}
                          placeholder="List past surgeries, chronic illnesses, or major medical events..."
                          className="w-full bg-slate-100 border-2 border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-navy/10 resize-none font-medium text-slate-900"
                        />
                      </div>
                    </div>
                  </section>

                  {/* Allergies Section */}
                  <section className="space-y-4">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center gap-2">
                        <AlertCircle size={20} className="text-amber-500" />
                        <h3 className="text-xl font-bold text-slate-800">Allergies</h3>
                      </div>
                      <button 
                        onClick={() => setShowAddAllergyForm(!showAddAllergyForm)}
                        className="p-1.5 bg-blue-50 hover:bg-blue-100 hover:scale-105 active:scale-95 text-blue-600 rounded-full border border-blue-200 transition-all cursor-pointer"
                        title="Add Allergy Trigger"
                      >
                        <Plus size={18} />
                      </button>
                    </div>

                    <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 p-5 space-y-4 text-slate-905">
                      {showAddAllergyForm ? (
                        <div className="bg-amber-50/20 p-4 rounded-2xl border border-amber-500/20 flex flex-col sm:flex-row gap-2">
                          <input 
                            type="text" 
                            placeholder="Add allergy trigger (e.g. Penicillin, Peanuts)..."
                            value={newAllergy}
                            onChange={e => setNewAllergy(e.target.value)}
                            onKeyDown={e => {
                              if (e.key === 'Enter' && newAllergy) {
                                if (!allergies.includes(newAllergy)) {
                                  setAllergies(prev => [...prev, newAllergy]);
                                }
                                setNewAllergy('');
                                setShowAddAllergyForm(false);
                              }
                            }}
                            className="flex-1 bg-white border-2 border-slate-300 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/10 text-slate-900 font-bold"
                          />
                          <div className="flex gap-2 shrink-0">
                            <button 
                              onClick={() => {
                                if (newAllergy && !allergies.includes(newAllergy)) {
                                  setAllergies(prev => [...prev, newAllergy]);
                                  setNewAllergy('');
                                }
                                setShowAddAllergyForm(false);
                              }}
                              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black text-xs cursor-pointer transition-all shadow"
                            >
                              Add
                            </button>
                            <button 
                              onClick={() => {
                                setNewAllergy('');
                                setShowAddAllergyForm(false);
                              }}
                              className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-xl font-bold text-xs cursor-pointer transition-all"
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setShowAddAllergyForm(true)}
                          className="w-full py-4 border-2 border-dashed border-slate-300 hover:border-blue-400 hover:bg-blue-50/10 rounded-2xl flex items-center justify-center gap-2 text-slate-500 hover:text-blue-600 font-bold text-xs transition-all cursor-pointer animate-fade-in"
                        >
                          <Plus size={16} />
                          <span>Add Allergy Trigger</span>
                        </button>
                      )}

                      <div className="flex flex-wrap gap-2 pt-2">
                        {allergies.map(allergy => (
                          <span key={allergy} className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-full text-xs font-black shadow-sm">
                            {allergy}
                            <button 
                              onClick={() => setAllergies(prev => prev.filter(a => a !== allergy))}
                              className="p-0.5 hover:text-red-650 hover:bg-amber-100 rounded-full transition-colors cursor-pointer"
                              title="Delete Allergy"
                            >
                              <X size={12} />
                            </button>
                          </span>
                        ))}
                        {allergies.length === 0 && <p className="text-xs text-slate-400 italic">No allergies listed</p>}
                      </div>
                    </div>
                  </section>

                  {/* PHYSICAL CARDS & DOCUMENT LOCKER */}
                  <section className="space-y-4">
                    <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                      <Camera size={20} className="text-blue-600" />
                      <h3 className="text-xl font-bold text-slate-800">Physical Cards & Document Locker</h3>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-slate-900">
                      {/* Insurance Card Slot */}
                      <div className="card flex flex-col gap-4">
                        <div className="text-left">
                          <h4 className="font-extrabold text-[10px] uppercase tracking-wider text-slate-400">Card 1</h4>
                          <h5 className="font-black text-lg text-slate-950">Health Insurance Card</h5>
                          <p className="text-xs text-slate-500 mt-1">Upload an image or snap a photo of your primary health insurance card.</p>
                        </div>

                        {insuranceCard ? (
                          <div className="relative group rounded-2xl overflow-hidden border border-slate-300">
                            <img src={insuranceCard} alt="Insurance Card" className="w-full h-40 object-cover" />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                              <button
                                onClick={() => {
                                  const win = window.open();
                                  if (win) {
                                    win.document.write(`<img src="${insuranceCard}" style="max-width:100%;height:auto;"/>`);
                                  }
                                }}
                                className="px-3 py-1.5 bg-slate-100 text-slate-900 font-bold rounded-lg text-xs hover:bg-slate-200 cursor-pointer"
                              >
                                View full
                              </button>
                              <button
                                onClick={() => {
                                  setInsuranceCard(null);
                                  localStorage.removeItem('medycard_insurance_card');
                                }}
                                className="px-3 py-1.5 bg-red-600 text-white font-bold rounded-lg text-xs hover:bg-red-700 cursor-pointer"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        ) : (
                          <label className="h-40 border-2 border-dashed border-slate-300 hover:border-slate-400 rounded-2xl flex flex-col items-center justify-center p-4 cursor-pointer text-center text-slate-500 hover:text-slate-700 transition-all bg-slate-50/50 shadow-inner">
                            <Camera size={32} className="mb-2 text-slate-400" />
                            <span className="text-xs font-bold font-sans">Click to upload or take a photo</span>
                            <span className="text-[10px] text-slate-400 mt-0.5">JPEG, PNG, or GIF up to 5MB</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    const base64 = reader.result as string;
                                    setInsuranceCard(base64);
                                    localStorage.setItem('medycard_insurance_card', base64);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </label>
                        )}
                      </div>

                        <div className="card flex flex-col gap-4">
                        <div className="text-left">
                          <h4 className="font-extrabold text-[10px] uppercase tracking-wider text-slate-400">Card 2</h4>
                          <h5 className="font-black text-lg text-slate-950">Vaccination or Rx Pharmacy Card</h5>
                          <p className="text-xs text-slate-500 mt-1">Keep a digital credential of vaccinations, prescriptions, or a secondary health card.</p>
                        </div>

                        {vaccinationCard ? (
                          <div className="relative group rounded-2xl overflow-hidden border border-slate-300">
                            <img src={vaccinationCard} alt="Vaccination Card" className="w-full h-40 object-cover" />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                              <button
                                onClick={() => {
                                  const win = window.open();
                                  if (win) {
                                    win.document.write(`<img src="${vaccinationCard}" style="max-width:100%;height:auto;"/>`);
                                  }
                                }}
                                className="px-3 py-1.5 bg-slate-100 text-slate-900 font-bold rounded-lg text-xs hover:bg-slate-200 cursor-pointer"
                              >
                                View full
                              </button>
                              <button
                                onClick={() => {
                                  setVaccinationCard(null);
                                  localStorage.removeItem('medycard_vaccination_card');
                                }}
                                className="px-3 py-1.5 bg-red-600 text-white font-bold rounded-lg text-xs hover:bg-red-700 cursor-pointer"
                              >
                                Delete
                              </button>
                            </div>
                          </div>
                        ) : (
                          <label className="h-40 border-2 border-dashed border-slate-300 hover:border-slate-400 rounded-2xl flex flex-col items-center justify-center p-4 cursor-pointer text-center text-slate-500 hover:text-slate-700 transition-all bg-slate-50/50 shadow-inner">
                            <Camera size={32} className="mb-2 text-slate-400" />
                            <span className="text-xs font-bold font-sans">Click to upload or take a photo</span>
                            <span className="text-[10px] text-slate-400 mt-0.5">JPEG, PNG, or Rx Slip photo</span>
                            <input
                              type="file"
                              accept="image/*"
                              className="hidden"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    const base64 = reader.result as string;
                                    setVaccinationCard(base64);
                                    localStorage.setItem('medycard_vaccination_card', base64);
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </label>
                        )}
                      </div>
                    </div>

                    {/* Shared Documents Gallery */}
                    <div className="card flex flex-col gap-4 mt-6 text-slate-900">
                      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                        <div>
                          <h5 className="font-black text-lg text-slate-950">Additional Encrypted Medical Records</h5>
                          <p className="text-xs text-slate-500 mt-0.5">Keep diagnostic logs, physical scan reports, or other medical images.</p>
                        </div>
                        <label className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer shadow-sm">
                          <Plus size={14} />
                          <span>Add Document</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                  const base64 = reader.result as string;
                                  const newDoc = { id: Date.now().toString(), name: file.name, data: base64 };
                                  const updated = [...safetyDocs, newDoc];
                                  setSafetyDocs(updated);
                                  localStorage.setItem('medycard_docs', JSON.stringify(updated));
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                      </div>

                      {safetyDocs.length === 0 ? (
                        <p className="text-xs text-slate-400 italic py-4 text-center">No additional medical documents uploaded to the offline vault.</p>
                      ) : (
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                          {safetyDocs.map((doc) => (
                            <div key={doc.id} className="relative group aspect-square rounded-xl overflow-hidden border border-slate-200 bg-white">
                              <img src={doc.data} alt={doc.name} className="w-full h-full object-cover animate-fade-in" />
                              <div className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center gap-1 p-2 transition-opacity">
                                <span className="text-[9px] font-bold text-white text-center truncate w-full mb-1">{doc.name}</span>
                                <div className="flex gap-1 shrink-0">
                                  <button
                                    onClick={() => {
                                      const win = window.open();
                                      if (win) {
                                        win.document.write(`<img src="${doc.data}" style="max-width:100%;height:auto;"/>`);
                                      }
                                    }}
                                    className="p-1 bg-white hover:bg-slate-100 text-slate-900 rounded font-bold text-[9px] cursor-pointer"
                                  >
                                    View
                                  </button>
                                  <button
                                    onClick={() => {
                                      const updated = safetyDocs.filter(x => x.id !== doc.id);
                                      setSafetyDocs(updated);
                                      localStorage.setItem('medycard_docs', JSON.stringify(updated));
                                    }}
                                    className="p-1 bg-red-650 hover:bg-red-700 text-white rounded font-bold text-[9px] cursor-pointer"
                                  >
                                    Del
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </section>

                   {/* APP PASSCODE SETTINGS */}
                   <section className="space-y-4">
                     <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
                       <Lock size={20} className="text-blue-600" />
                       <h3 className="text-xl font-bold text-slate-800">Passcode Security</h3>
                     </div>
                     <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 p-6 rounded-2xl">
                      <p className="text-xs text-slate-600 mb-4 font-semibold leading-relaxed">
                        Customize the 4-digit security code used to lock and unlock MedyCard Pro on startup.
                      </p>
                      <div className="flex flex-col sm:flex-row gap-3 items-end">
                        <div className="flex-1 space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase">Current App Code</label>
                          <input 
                            type="text" 
                            disabled 
                            value={appPin}
                            className="w-full bg-slate-100 border-2 border-slate-200 rounded-xl px-4 py-2 text-sm text-slate-500 font-mono"
                          />
                        </div>
                        <div className="flex-1 space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase">New 4-Digit Code</label>
                          <input 
                            type="text" 
                            maxLength={4}
                            placeholder="e.g. 5678"
                            id="newPinInput"
                            className="w-full bg-slate-50 border-2 border-slate-300 rounded-xl px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-navy/5 text-slate-900 font-mono"
                          />
                        </div>
                        <button
                          onClick={() => {
                            const newPin = (document.getElementById('newPinInput') as HTMLInputElement)?.value;
                            if (newPin && newPin.length === 4 && /^\d{4}$/.test(newPin)) {
                              setAppPin(newPin);
                              localStorage.setItem('medycard_pin', newPin);
                              setPasscodeFeedback('Passcode updated successfully to: ' + newPin);
                              (document.getElementById('newPinInput') as HTMLInputElement).value = '';
                              setTimeout(() => setPasscodeFeedback(''), 4000);
                            } else {
                              setPasscodeFeedback('Error: Please enter a valid 4-digit numeric code.');
                              setTimeout(() => setPasscodeFeedback(''), 4000);
                            }
                          }}
                          className="px-6 py-2 bg-blue-600 text-white font-black text-xs rounded-xl hover:bg-blue-700 transition-all active:scale-95 whitespace-nowrap h-10 shadow-lg shadow-blue-600/10"
                        >
                          Save Passcode
                        </button>
                      </div>

                      {passcodeFeedback && (
                        <p className={cn(
                          "text-xs font-bold mt-3 animate-fade-in",
                          passcodeFeedback.startsWith('Error') ? "text-red-500" : "text-emerald-500"
                        )}>
                          {passcodeFeedback}
                        </p>
                      )}
                    </div>
                  </section>

                  <div className="bg-navy rounded-2xl p-8 text-white relative overflow-hidden">
                    <div className="relative z-10">
                      <h3 className="text-xl font-bold mb-2">Zero-Knowledge Encryption</h3>
                      <p className="text-blue-100 text-sm max-w-md">
                        MedyCard Pro uses end-to-end encryption. Only you hold the keys to your medical history.
                      </p>
                    </div>
                    <Lock size={120} className="absolute -right-4 -bottom-4 text-white/5" />
                  </div>
                </motion.div>
              )}

              {activePage === 'family' && (
                <motion.div 
                  key="family"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="space-y-8 p-4 md:p-6 w-full"
                >
                  <header>
                    <h2 className="text-3xl font-black text-slate-100">Family Hub</h2>
                    <p className="text-blue-400 text-sm">Manage emergency contacts and share real-time safety status.</p>
                  </header>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {contacts.map(contact => (
                      <div key={contact.id} className="card w-full max-w-lg lg:max-w-none mx-auto flex flex-col gap-4 mb-4 text-slate-900 bg-slate-100/90 border-2 border-slate-300">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-slate-200/80 rounded-full flex items-center justify-center text-slate-900 font-extrabold text-lg shadow-inner">
                            {contact.name.charAt(0)}
                          </div>
                          <div className="flex-1 text-left">
                            <h4 className="font-extrabold text-slate-900 text-base">{contact.name}</h4>
                            <p className="text-xs text-red-650 font-bold">{contact.relation}</p>
                            <p className="text-xs font-mono text-slate-500 mt-0.5">{contact.phone}</p>
                          </div>
                          <button 
                            onClick={() => {
                              setContacts(prev => prev.filter(c => c.id !== contact.id));
                            }}
                            className="text-slate-400 hover:text-red-650 transition-colors p-2 rounded-xl hover:bg-slate-200 cursor-pointer shrink-0"
                            title="Delete Contact"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-2">
                          <a href={`tel:${contact.phone}`} className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-navy hover:bg-navy/95 text-white rounded-xl text-xs font-black transition-all">
                            <Phone size={14} />
                            Call Contact
                          </a>
                          <button 
                            onClick={() => {
                              alert(`Simulating dynamic location share request with ${contact.name}! A secure SMS link has been dispatched.`);
                            }}
                            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-900 rounded-xl text-xs font-black transition-all"
                          >
                            <Share2 size={14} />
                            Share Location
                          </button>
                        </div>
                      </div>
                    ))}

                    {showAddContactForm ? (
                      <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 border-2 border-navy/35 bg-white p-6 rounded-[2rem] text-slate-900 flex flex-col gap-4 text-left">
                        <h4 className="font-black text-lg text-slate-905">Add Emergency Contact / Responder</h4>
                        
                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase">Contact Name</label>
                          <input 
                            type="text" 
                            placeholder="e.g. Mary Jane" 
                            value={newContact.name}
                            onChange={e => setNewContact(prev => ({ ...prev, name: e.target.value }))}
                            className="w-full bg-slate-100 border-2 border-slate-200 rounded-xl px-4 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy/15"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase">Relationship / Title</label>
                          <input 
                            type="text" 
                            placeholder="e.g. Wife, Caregiver, Primary Doctor" 
                            value={newContact.relation}
                            onChange={e => setNewContact(prev => ({ ...prev, relation: e.target.value }))}
                            className="w-full bg-slate-100 border-2 border-slate-200 rounded-xl px-4 py-2 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy/15"
                          />
                        </div>

                        <div className="space-y-1.5">
                          <label className="text-[10px] font-black text-slate-400 uppercase">Phone Number</label>
                          <input 
                            type="text" 
                            placeholder="e.g. +1 (555) 012-3456" 
                            value={newContact.phone}
                            onChange={e => setNewContact(prev => ({ ...prev, phone: e.target.value }))}
                            className="w-full bg-slate-100 border-2 border-slate-200 rounded-xl px-4 py-2 text-sm text-slate-900 font-mono focus:outline-none focus:ring-2 focus:ring-navy/15"
                          />
                        </div>

                        <div className="flex gap-2 mt-2">
                          <button 
                            onClick={() => {
                              if (newContact.name && newContact.relation && newContact.phone) {
                                setContacts(prev => [...prev, {
                                  id: Date.now().toString(),
                                  name: newContact.name,
                                  relation: newContact.relation,
                                  phone: newContact.phone
                                }]);
                                setNewContact({ name: '', relation: '', phone: '' });
                                setShowAddContactForm(false);
                              } else {
                                alert("Please fill up all contact fields (Name, Relationship, and Phone Number)");
                              }
                            }}
                            className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-black rounded-xl transition-all shadow-md cursor-pointer text-center"
                          >
                            Save Care Partner
                          </button>
                          <button 
                            onClick={() => {
                              setNewContact({ name: '', relation: '', phone: '' });
                              setShowAddContactForm(false);
                            }}
                            className="px-4 py-2.5 bg-slate-200 hover:bg-slate-300 text-slate-900 text-xs font-black rounded-xl transition-all cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button 
                        onClick={() => setShowAddContactForm(true)}
                        className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 border-dashed border-2 border-slate-300 flex flex-col items-center justify-center gap-2 text-slate-500 hover:border-navy hover:text-navy transition-all min-h-[178px] bg-slate-50/20"
                      >
                        <Plus size={24} />
                        <span className="text-sm font-bold">Add New Contact</span>
                      </button>
                    )}
                  </div>

                  <div className="mt-8">
                    <div className="flex items-center gap-2 border-b border-slate-200 pb-2 mb-4">
                      <History size={20} className="text-slate-900" />
                      <h3 className="text-xl font-bold text-slate-800">Caregiver Access Log</h3>
                    </div>
                    <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 overflow-hidden p-0">
                      <div className="bg-slate-100 p-3 border-b border-slate-200 grid grid-cols-1 md:grid-cols-3 gap-2 text-[10px] font-black text-blue-900 uppercase tracking-widest">
                        <span>Caregiver</span>
                        <span>Action</span>
                        <span>Time</span>
                      </div>
                      <div className="divide-y divide-slate-200">
                        {caregiverLogs.map(log => (
                          <div key={log.id} className="p-4 grid grid-cols-1 md:grid-cols-3 items-start md:items-center text-sm gap-2">
                            <span className="font-bold text-slate-900">{log.name}</span>
                            <span className="text-slate-600">{log.action}</span>
                            <span className="text-slate-500 text-xs">{log.time}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activePage === 'lab' && (
                <motion.div 
                  key="lab"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="space-y-8 p-4 md:p-6 w-full"
                >
                  <header>
                    <h2 className="text-3xl font-black text-slate-100">Lab Lens</h2>
                    <p className="text-blue-400 text-sm">Upload or scan medical reports for instant AI analysis.</p>
                  </header>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Upload / Scan Section */}
                    <div className="space-y-6">
                      <div 
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={onDrop}
                        className={cn(
                          "card aspect-video border-dashed border-4 flex flex-col items-center justify-center text-center p-8 transition-all cursor-pointer group border-t-emerald-400",
                          uploadedFile ? "border-blue-500 bg-blue-50" : "border-slate-300 hover:border-blue-400 hover:bg-slate-50"
                        )}
                        onClick={() => fileInputRef.current?.click()}
                      >
                        <input 
                          type="file" 
                          ref={fileInputRef}
                          className="hidden" 
                          accept="image/*,application/pdf"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) handleFileUpload(file);
                          }}
                        />
                        {isAnalyzing ? (
                          <div className="space-y-4">
                            <Loader2 size={48} className="animate-spin text-blue-600 mx-auto" />
                            <p className="text-lg font-black text-slate-900">Analyzing Report...</p>
                            <p className="text-xs text-slate-500 uppercase tracking-widest">MedyCard Pro AI is processing your data</p>
                          </div>
                        ) : uploadedFile ? (
                          <div className="space-y-4">
                            <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto text-blue-600">
                              <FileText size={32} />
                            </div>
                            <div>
                              <p className="text-lg font-black text-slate-900">{uploadedFile.name}</p>
                              <p className="text-xs text-slate-500">File uploaded successfully</p>
                            </div>
                            <button className="text-blue-600 text-xs font-bold uppercase tracking-widest hover:underline">
                              Change File
                            </button>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mx-auto text-slate-400 group-hover:text-blue-500 transition-colors">
                              <Plus size={32} />
                            </div>
                            <div>
                              <p className="text-lg font-black text-slate-900">Drop Lab Report Here</p>
                              <p className="text-sm text-slate-500">or click to browse (Images or PDF)</p>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex-1 h-px bg-slate-300" />
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">OR</span>
                        <div className="flex-1 h-px bg-slate-300" />
                      </div>

                      <button 
                        onClick={() => setIsScanning(!isScanning)}
                        className={cn(
                          "w-full py-4 rounded-2xl font-black flex items-center justify-center gap-3 shadow-xl transition-all border-2",
                          isScanning ? "bg-red-600 border-red-700 text-white" : "bg-slate-50 border-slate-300 text-slate-900 hover:bg-slate-100"
                        )}
                      >
                        <Camera size={24} />
                        {isScanning ? "Stop Camera" : "Scan with Camera"}
                      </button>

                      {isScanning && (
                        <div className="card aspect-video bg-slate-800 rounded-3xl overflow-hidden relative">
                          <video 
                            ref={videoRef} 
                            autoPlay 
                            playsInline 
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 border-2 border-white/20 pointer-events-none m-8 rounded-2xl">
                            <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-red-600 -mt-1 -ml-1" />
                            <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-red-600 -mt-1 -mr-1" />
                            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-red-600 -mb-1 -ml-1" />
                            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-red-600 -mb-1 -mr-1" />
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Analysis Result Section */}
                    <div className="space-y-6">
                        <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 min-h-[400px] flex flex-col p-0 overflow-hidden border-t-emerald-400">
                        <div className="bg-slate-800 p-4 text-white flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Activity size={18} className="text-blue-400" />
                            <span className="font-black text-xs uppercase tracking-widest">AI Analysis Report</span>
                          </div>
                          {labAnalysisResult && (
                            <button 
                              onClick={() => {
                                setLabAnalysisResult(null);
                                setUploadedFile(null);
                              }}
                              className="text-white/60 hover:text-white transition-colors"
                            >
                              <X size={18} />
                            </button>
                          )}
                        </div>

                        <div className="flex-1 p-6 overflow-y-auto">
                          {labAnalysisResult ? (
                            <div className="space-y-6">
                              <div className="markdown-body text-slate-900">
                                <Markdown>{labAnalysisResult}</Markdown>
                              </div>
                            </div>
                          ) : isAnalyzing ? (
                            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50">
                              <Loader2 size={48} className="animate-spin text-blue-600" />
                              <p className="font-black text-slate-900">Processing Clinical Data...</p>
                            </div>
                          ) : (
                            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 opacity-30">
                              <FileText size={64} className="text-slate-400" />
                              <div>
                                <p className="font-black text-slate-900 text-lg">No Report Analyzed</p>
                                <p className="text-sm text-slate-500">Upload a lab report to see AI insights</p>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 p-4 flex flex-col items-center text-center gap-2 border-t-emerald-400">
                          <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center text-emerald-600">
                            <ShieldCheck size={18} />
                          </div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Privacy</p>
                          <p className="text-[10px] font-bold text-slate-900">HIPAA Compliant</p>
                        </div>
                        <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 p-4 flex flex-col items-center text-center gap-2 border-t-emerald-400">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600">
                            <Lock size={18} />
                          </div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Security</p>
                          <p className="text-[10px] font-bold text-slate-900">Encrypted</p>
                        </div>
                        <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 p-4 flex flex-col items-center text-center gap-2 border-t-emerald-400">
                          <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center text-amber-600">
                            <AlertCircle size={18} />
                          </div>
                          <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">Disclaimer</p>
                          <p className="text-[10px] font-bold text-slate-900">Not Diagnosis</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activePage === 'check' && (
                <motion.div 
                  key="check"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                  className="space-y-8 p-4 md:p-6 w-full"
                >
                  <header>
                    <h2 className="text-3xl font-black text-slate-100">Med-Check</h2>
                    <p className="text-blue-400 text-sm">Verify medication interactions and safety risks.</p>
                  </header>

                  <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 space-y-6">
                    <div className="space-y-4">
                      <h3 className="font-bold text-sm uppercase tracking-wider text-slate-800">Select Medications to Compare</h3>
                      <div className="flex gap-2">
                        <input 
                          type="text" 
                          placeholder="Enter medication name (e.g. Aspirin)"
                          onKeyDown={e => {
                            if (e.key === 'Enter' && (e.target as HTMLInputElement).value) {
                              const val = (e.target as HTMLInputElement).value;
                              if (!checkMeds.includes(val)) {
                                setCheckMeds(prev => [...prev, val]);
                              }
                              (e.target as HTMLInputElement).value = '';
                            }
                          }}
                          className="flex-1 bg-slate-100 border-2 border-slate-300 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-navy/10"
                        />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {checkMeds.map(med => (
                          <span key={med} className="flex items-center gap-2 px-4 py-2 bg-navy text-white rounded-xl text-sm font-medium">
                            {med}
                            <button onClick={() => setCheckMeds(prev => prev.filter(m => m !== med))}>
                              <X size={14} />
                            </button>
                          </span>
                        ))}
                        {checkMeds.length === 0 && <p className="text-sm text-slate-400 italic">Add at least two medications to check for risks.</p>}
                      </div>
                    </div>

                    <AnimatePresence mode="wait">
                      {riskStatus !== 'none' && (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.95 }}
                          className={cn(
                            "p-6 rounded-2xl border-2 flex flex-col items-center text-center gap-4",
                            riskStatus === 'high' 
                              ? "bg-red-50 border-red-100 text-red-900" 
                              : "bg-emerald-50 border-emerald-100 text-emerald-900"
                          )}
                        >
                          <div className={cn(
                            "w-16 h-16 rounded-full flex items-center justify-center",
                            riskStatus === 'high' ? "bg-red-100 text-red-600" : "bg-emerald-100 text-emerald-600"
                          )}>
                            {riskStatus === 'high' ? <AlertTriangle size={32} /> : <ShieldCheck size={32} />}
                          </div>
                          <div>
                            <h4 className="text-xl font-bold">
                              {riskStatus === 'high' ? "High Risk Interaction Detected" : "No Known Major Interactions"}
                            </h4>
                            <p className="text-sm opacity-80 mt-1">
                              {riskStatus === 'high' 
                                ? "These medications may have serious adverse effects when taken together. Consult your doctor immediately." 
                                : "Based on our database, these medications appear safe to take together. Always verify with a professional."}
                            </p>
                          </div>
                          {riskStatus === 'high' && (
                            <div className="w-full bg-slate-50/50 p-4 rounded-xl text-xs text-left">
                              <p className="font-bold mb-1">Interaction Details:</p>
                              <p>Lisinopril and Aspirin can interact to reduce the effectiveness of the blood pressure medication and increase risk of kidney issues.</p>
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <div className="bg-slate-100 rounded-2xl p-6 flex items-start gap-4">
                    <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-900 shrink-0">
                      <Activity size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">Pro Tip</h4>
                      <p className="text-xs text-slate-600 mt-1">Try checking 'Lisinopril' and 'Aspirin' to see a high-risk warning example.</p>
                    </div>
                  </div>
                </motion.div>
              )}

              {activePage === 'journal' && (
                <motion.div 
                  key="journal"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8 p-4 md:p-6 w-full text-slate-900"
                >
                  <header className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div>
                      <h2 className="text-3xl font-black text-slate-100">Pain & Inflammation Journal</h2>
                      <p className="text-blue-400 text-sm">Offline, zero-knowledge clinical log-diary of local discomfort and daily progress.</p>
                    </div>
                    <div className="flex items-center gap-2 text-rose-600 bg-rose-50 px-3 py-1.5 rounded-full border border-rose-100 font-bold text-xs shrink-0 shadow-sm">
                      <Activity size={14} className="animate-pulse" />
                      <span>Symptom Tracker</span>
                    </div>
                  </header>

                  {/* 1. Pain Scale Selector & Info */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-6">
                      <div className="card flex flex-col gap-6">
                        <div className="space-y-1">
                          <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400">Step 1</span>
                          <h3 className="text-xl font-black text-slate-900">How severe is your pain level right now?</h3>
                          <p className="text-xs text-slate-500">Pick a number from 1 (minimal) to 10 (emergency).</p>
                        </div>

                        {/* Beautiful color scale rendering */}
                        <div className="grid grid-cols-5 md:grid-cols-10 gap-2">
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => {
                            let colorClass = "bg-emerald-500 hover:bg-emerald-600 focus:ring-emerald-300";
                            if (num >= 4 && num <= 7) colorClass = "bg-amber-500 hover:bg-amber-600 focus:ring-amber-300";
                            if (num >= 8) colorClass = "bg-red-500 hover:bg-red-600 focus:ring-red-350";

                            const isSelected = pendingPainLevel === num;

                            return (
                              <button
                                key={num}
                                onClick={() => setPendingPainLevel(num)}
                                className={cn(
                                  "h-12 w-full rounded-xl text-white font-black text-lg transition-all transform active:scale-95 focus:outline-none focus:ring-4 shadow-sm relative",
                                  colorClass,
                                  isSelected ? "ring-4 ring-slate-800 ring-offset-2 scale-110 z-10" : "opacity-85"
                                )}
                              >
                                {num}
                                {isSelected && (
                                  <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 rounded-full bg-slate-800 border-2 border-white" />
                                )}
                              </button>
                            );
                          })}
                        </div>

                        <div className="flex justify-between items-center text-xs text-slate-500 font-bold border-t border-slate-200/80 pt-3">
                          <span className="text-emerald-600">🟢 1-3 MILD</span>
                          <span className="text-amber-600">🟡 4-7 MODERATE</span>
                          <span className="text-red-700 font-black">🔴 8-10 SEVERE</span>
                        </div>
                      </div>

                      {/* Location & Summary Block */}
                      <div className="card flex flex-col gap-6">
                        <div className="space-y-1">
                          <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400">Step 2</span>
                          <h3 className="text-xl font-black text-slate-900">Select Pain Location</h3>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {["Head", "Neck", "Shoulders", "Chest", "Abdomen", "Back", "Hips", "Knees", "Feet", "General"].map((loc) => {
                            const isSel = pendingLocation === loc;
                            return (
                              <button
                                key={loc}
                                onClick={() => setPendingLocation(loc)}
                                className={cn(
                                  "px-4 py-2 rounded-xl text-xs font-bold transition-all transform active:scale-95 border-2 cursor-pointer",
                                  isSel 
                                    ? "bg-slate-900 border-slate-900 text-white shadow-md shadow-slate-900/10" 
                                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-200/50"
                                )}
                              >
                                {loc}
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Notes Description */}
                      <div className="card flex flex-col gap-4">
                        <div className="space-y-1">
                          <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400">Step 3</span>
                          <h3 className="text-xl font-black text-slate-900">Daily Symptoms & Inflammation Notes</h3>
                        </div>

                        <textarea
                          rows={3}
                          placeholder="e.g. Throbbing localized headache after waking up. Took 200mg ibuprofen. Resting in a dark quiet room."
                          value={pendingNotes}
                          onChange={(e) => setPendingNotes(e.target.value)}
                          className="w-full bg-slate-50 border-2 border-slate-200 rounded-xl p-4 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-800/15 focus:border-slate-400 transition-all"
                        />

                        <button
                          onClick={() => {
                            const entry: PainLog = {
                              id: Date.now().toString(),
                              date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
                              pain: pendingPainLevel,
                              location: pendingLocation,
                              notes: pendingNotes.trim()
                            };
                            const updated = [entry, ...journal];
                            setJournal(updated);
                            localStorage.setItem('medycard_journal', JSON.stringify(updated));
                            setPendingNotes('');
                            setPendingPainLevel(5);
                          }}
                          className="w-full bg-rose-600 text-white font-black py-4 rounded-xl shadow-lg shadow-rose-600/25 hover:bg-rose-700 active:scale-95 transition-all text-base flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Plus size={18} />
                          <span>Save Symptom Log Entry</span>
                        </button>
                      </div>
                    </div>

                    {/* Left Panel Sidebar: Analytics Trend Chart & Fast Reports */}
                    <div className="space-y-6">
                      <div className="card flex flex-col gap-6">
                        <div className="space-y-1">
                          <span className="text-xs uppercase font-extrabold tracking-wider text-slate-400">Trend Analysis</span>
                          <h3 className="text-xl font-black text-slate-900">Last 7 Entries</h3>
                        </div>

                        {journal.length === 0 ? (
                          <div className="py-8 text-center text-slate-400 italic text-sm">
                            No log history to render trend analytics. Save your first pain entry to populate this graph!
                          </div>
                        ) : (
                          <div className="space-y-6">
                            {/* Pure HTML Bar Chart */}
                            <div className="h-32 flex items-end gap-3 justify-between px-2 pt-4 border-b border-slate-200">
                              {[...journal].slice(0, 7).reverse().map((entry) => {
                                let col = "bg-emerald-500";
                                if (entry.pain >= 4 && entry.pain <= 7) col = "bg-amber-500";
                                if (entry.pain >= 8) col = "bg-red-500";
                                const heightPct = (entry.pain / 10) * 100;

                                return (
                                  <div key={entry.id} className="flex-1 flex flex-col items-center gap-1 group relative">
                                    {/* Tooltip */}
                                    <div className="absolute -top-10 opacity-0 group-hover:opacity-100 transition-opacity bg-black text-white text-[10px] font-bold rounded px-1.5 py-0.5 pointer-events-none whitespace-nowrap z-30">
                                      {entry.location}: {entry.pain}/10
                                    </div>
                                    {/* Active Bar */}
                                    <div 
                                      className={cn("w-full rounded-t-lg transition-all", col)}
                                      style={{ height: `${heightPct}%`, minHeight: '12px' }}
                                    />
                                    <span className="text-[9px] font-bold text-slate-450 truncate w-full text-center">
                                      {entry.location.slice(0, 3)}
                                    </span>
                                  </div>
                                );
                              })}
                            </div>

                            <div className="grid grid-cols-2 gap-4 text-center">
                              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                                <p className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider">Average Pain</p>
                                <p className="text-2xl font-black text-slate-900 mt-1">
                                  {(journal.reduce((sum, j) => sum + j.pain, 0) / journal.length).toFixed(1)}
                                  <span className="text-xs text-slate-500 font-bold">/10</span>
                                </p>
                              </div>
                              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
                                <p className="text-[10px] uppercase font-extrabold text-slate-400 tracking-wider">Peak Recorded</p>
                                <p className="text-2xl font-black text-red-650 mt-1">
                                  {Math.max(...journal.map(j => j.pain))}
                                  <span className="text-xs text-slate-500 font-bold">/10</span>
                                </p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Past Logs */}
                      <div className="card flex flex-col gap-4">
                        <div className="flex items-center justify-between">
                          <h4 className="font-bold text-slate-900 text-sm">Past Records</h4>
                          <span className="text-xs bg-slate-200 px-2 py-0.5 rounded-full font-bold text-slate-650">{journal.length} Logs</span>
                        </div>

                        <div className="max-h-[350px] overflow-y-auto space-y-3 pr-1 scrollbar-hide">
                          {journal.map((item) => {
                            let badgeCol = "bg-emerald-100 text-emerald-800 border-emerald-200";
                            if (item.pain >= 4 && item.pain <= 7) badgeCol = "bg-amber-100 text-amber-805 border-amber-200";
                            if (item.pain >= 8) badgeCol = "bg-rose-100 text-rose-800 border-rose-200";

                            return (
                              <div key={item.id} className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl space-y-2 relative group hover:border-slate-300 transition-all">
                                <div className="flex items-start justify-between">
                                  <div className="flex items-center gap-1.5">
                                    <span className={cn("text-[10px] font-black px-2 py-0.5 rounded-lg border", badgeCol)}>
                                      Level {item.pain}
                                    </span>
                                    <span className="text-[10px] font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md border border-slate-200">
                                      {item.location}
                                    </span>
                                  </div>
                                  <button
                                    onClick={() => {
                                      const updated = journal.filter(x => x.id !== item.id);
                                      setJournal(updated);
                                      localStorage.setItem('medycard_journal', JSON.stringify(updated));
                                    }}
                                    className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-650 transition-all absolute top-2 right-2 text-xs font-black bg-slate-100 hover:bg-slate-200 p-1 rounded cursor-pointer"
                                    title="Delete entry"
                                  >
                                    <X size={12} />
                                  </button>
                                </div>
                                <p className="text-[11px] font-semibold text-slate-600 leading-relaxed italic pr-4">
                                  "{item.notes || 'No symptoms or notes written.'}"
                                </p>
                                <p className="text-[9px] font-bold text-slate-400 font-mono">
                                  {item.date}
                                </p>
                              </div>
                            );
                          })}
                          {journal.length === 0 && (
                            <div className="py-6 text-center text-slate-400 text-xs italic">
                              No logs recorded yet. Daily entries keep care partners informed.
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

              {activePage === 'travel' && (
                <motion.div 
                  key="travel"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8 p-4 md:p-6 w-full"
                >
                  <header>
                    <h2 className="text-3xl font-black text-slate-100">Travel Guard</h2>
                    <p className="text-blue-400 text-sm">Global medical protection wherever you go.</p>
                  </header>

                  <div className="relative">
                    <Search size={20} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Enter destination (e.g., Tokyo, Japan)"
                      className="w-full bg-slate-50 border-2 border-slate-300 rounded-2xl px-12 py-4 text-slate-900 focus:outline-none focus:ring-2 focus:ring-navy/10 shadow-md"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                    <div className="space-y-4">
                      <h3 className="font-bold flex items-center gap-2 text-slate-100">
                        <Plane size={20} className="text-blue-400" />
                        Destination Health Advice
                      </h3>
                      <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 space-y-4">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center text-amber-700 shrink-0">
                            <ShieldCheck size={18} />
                          </div>
                          <div>
                            <h5 className="text-sm font-black text-slate-900">Vaccinations Recommended</h5>
                            <p className="text-xs text-slate-700 font-medium">Hepatitis A, Typhoid, and Routine vaccines.</p>
                          </div>
                        </div>
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-blue-800 shrink-0">
                            <MapPin size={18} />
                          </div>
                          <div>
                            <h5 className="text-sm font-black text-slate-900">Local Emergency Numbers</h5>
                            <p className="text-xs text-slate-700 font-semibold">Ambulance: 119 | Police: 110</p>
                          </div>
                        </div>
                      </div>

                      <h3 className="font-bold flex items-center gap-2 text-slate-100 pt-4">
                        <Globe size={20} className="text-blue-400" />
                        Travel Details
                      </h3>
                      <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 space-y-4">
                        <div className="flex flex-col gap-3">
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-left">Flight Info</p>
                          <PrivacyOverlay isActive={isPrivacyShieldActive}>
                            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-1 text-left">
                              <span className="text-sm font-black text-slate-900">NH204 — Gate 52</span>
                              <span className="text-xs text-slate-600 font-bold text-left md:text-right">14:20 Departure</span>
                            </div>
                          </PrivacyOverlay>
                        </div>
                        <div className="flex flex-col gap-3">
                          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest text-left">Hotel Reservation</p>
                          <PrivacyOverlay isActive={isPrivacyShieldActive}>
                            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-1 text-left">
                              <span className="text-sm font-black text-slate-900">Park Hyatt Tokyo</span>
                              <span className="text-xs text-slate-600 font-bold text-left md:text-right">Conf: #82910</span>
                            </div>
                          </PrivacyOverlay>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="font-bold flex items-center gap-2 text-slate-100">
                        <Globe size={20} className="text-blue-400" />
                        Travel AI Assistant
                      </h3>
                      <div className="card w-full max-w-lg lg:max-w-none mx-auto mb-4 h-[250px] flex flex-col p-0 overflow-hidden">
                        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-hide text-left">
                          {messages.travel.length === 0 && (
                            <div className="h-full flex flex-col items-center justify-center text-center p-4">
                              <p className="text-xs text-slate-800 font-black mb-1">
                                Travel Guard Assistant
                              </p>
                              <p className="text-xs text-slate-600 font-semibold leading-relaxed">
                                Ask about required Travel Vaccinations, Flight Info, local weather warnings, or destination medical guidelines.
                              </p>
                              <p className="text-[10px] text-slate-400 font-medium italic mt-2">
                                e.g. "What medications are forbidden in Japan?" or "Is custom medical coverage active?"
                              </p>
                            </div>
                          )}
                          {messages.travel.map(msg => (
                            <div key={msg.id} className={cn("flex text-left", msg.role === 'user' ? "justify-end" : "justify-start")}>
                              <div className={cn(
                                "max-w-[90%] p-2.5 rounded-xl text-xs leading-relaxed text-left font-medium shadow-sm",
                                msg.role === 'user' ? "bg-navy text-white" : "bg-slate-200 text-slate-950"
                              )}>
                                <Markdown>{msg.content}</Markdown>
                                {msg.sources && msg.sources.length > 0 && (
                                  <div className="mt-2 flex flex-wrap gap-1">
                                    {msg.sources.map((s, i) => (
                                      <a key={i} href={s.uri} target="_blank" className="text-[8px] text-blue-600 flex items-center gap-0.5">
                                        <ExternalLink size={8} /> Source
                                      </a>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="p-3 border-t border-slate-200 bg-slate-50 flex gap-2">
                          <input 
                            type="text" 
                            value={input}
                            onChange={e => setInput(e.target.value)}
                            onKeyDown={e => e.key === 'Enter' && handleSend()}
                            placeholder="Ask Travel Guard..."
                            className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-1.5 text-xs text-slate-900 focus:outline-none placeholder-slate-400 font-medium"
                          />
                          <button onClick={handleSend} className="p-1.5 bg-navy text-white rounded-lg hover:bg-navy/90 active:scale-95 transition-all cursor-pointer">
                            <Send size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

        {/* Mobile Floating Controls removed in favor of main content cards as requested */}
        {/* Bottom Tab Bar (Mobile) */}
        <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-slate-900 border-t border-slate-600 z-50 px-6 py-4 flex items-center justify-between shadow-[0_-10px_30px_rgba(0,0,0,0.2)]">
          <button 
            onClick={() => setShowEmergencyOverlay(true)}
            className={cn("flex flex-col items-center gap-y-1", showEmergencyOverlay ? "text-slate-100" : "text-slate-300")}
          >
            <AlertCircle size={20} />
            <span className="text-[10px] font-bold">Hub</span>
          </button>
          <button 
            onClick={() => setActivePage('vault')}
            className={cn("flex flex-col items-center gap-y-1", activePage === 'vault' ? "text-slate-100" : "text-slate-300")}
          >
            <ShieldCheck size={20} />
            <span className="text-[10px] font-bold">Vault</span>
          </button>
          <button 
            onClick={() => setActivePage('journal')}
            className={cn("flex flex-col items-center gap-y-1", activePage === 'journal' ? "text-slate-100" : "text-slate-300")}
          >
            <Activity size={20} />
            <span className="text-[10px] font-bold">Journal</span>
          </button>
          <button 
            onClick={() => setActivePage('lab')}
            className={cn("flex flex-col items-center gap-y-1", activePage === 'lab' ? "text-slate-100" : "text-slate-300")}
          >
            <Camera size={20} />
            <span className="text-[10px] font-bold">Lens</span>
          </button>
          <button 
            onClick={() => setActivePage('family')}
            className={cn("flex flex-col items-center gap-y-1", activePage === 'family' ? "text-slate-100" : "text-slate-300")}
          >
            <Users size={20} />
            <span className="text-[10px] font-bold">Family</span>
          </button>
        </div>

        {/* Floating Action Buttons removed */}
        <AnimatePresence>
          {showEmergencyOverlay && (
            <motion.div 
              key="emergency-overlay"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setShowEmergencyOverlay(false);
                if (!isUnlocked) {
                  setIsUnmasked(false);
                }
              }}
              className="fixed inset-0 z-[2550] bg-slate-900/95 backdrop-blur-xl p-4 md:p-10 overflow-y-auto flex items-start justify-center cursor-pointer"
            >
              <div 
                onClick={(e) => e.stopPropagation()}
                className="w-full max-w-5xl relative mt-2 md:mt-10 cursor-default"
              >
                <div className="h-full">
                  <header className="px-4 md:px-6 pt-2 md:pt-4 flex items-center justify-between gap-4">
                    <div className="text-left">
                      <h2 className="text-xl md:text-2xl font-black text-slate-100">Emergency Hub</h2>
                      <p className="text-blue-400 text-[10px] md:text-xs">Instant access to life-saving medical data for first responders.</p>
                    </div>
                    <button 
                      onClick={() => {
                        setShowEmergencyOverlay(false);
                        if (!isUnlocked) {
                          setIsUnmasked(false);
                        }
                      }}
                      className="bg-red-650 hover:bg-red-700 hover:text-white border border-red-500/30 text-white px-3.5 py-2 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer shrink-0"
                      title="Close"
                    >
                      <X size={16} />
                      <span className="hidden sm:inline">CLOSE</span>
                    </button>
                  </header>
                  <div id="emergency-blueprint" ref={emergencyHubRef} className="grid grid-cols-1 md:grid-cols-2 w-full gap-6 p-4 md:p-6 h-auto min-h-[60px]">

                    {/* Left Column: Emergency Essentials */}
                    <div className={cn(
                      "card w-full max-w-lg lg:max-w-none mx-auto p-4 md:p-6 mb-4 border-t-4 border-t-red-400 text-slate-900",
                      isUnmasked && "ring-4 ring-emerald-400/30 shadow-[0_0_30px_rgba(52,211,153,0.2)]"
                    )}>
                      <div className="flex items-center justify-between mb-4">
                        <h2 className="text-2xl font-black text-slate-900">Emergency Essentials</h2>
                        {isUnmasked && (
                          <div className="flex items-center gap-1.5 text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100 animate-pulse">
                            <ShieldCheck size={14} />
                            <span className="text-[10px] font-black uppercase tracking-wider">Verified Access</span>
                          </div>
                        )}
                      </div>

                      <div className="space-y-6">
                        <div className="space-y-1">
                          <p className={cn(
                            "text-sm font-bold uppercase transition-all duration-300",
                            isFlashing ? "text-red-600" : "text-slate-900"
                          )}>Blood Type</p>
                          <PrivacyOverlay isActive={isPrivacyShieldActive}>
                            <p className={cn(
                              "text-lg font-black text-slate-900 transition-all duration-500",
                              isFlashing && "bg-yellow-200 px-2 rounded"
                            )}>{bloodType}</p>
                          </PrivacyOverlay>
                        </div>

                        <div className="space-y-1">
                          <p className={cn(
                            "text-sm font-bold uppercase transition-all duration-300",
                            isFlashing ? "text-red-600" : "text-slate-900"
                          )}>Severe Allergies</p>
                          <PrivacyOverlay isActive={isPrivacyShieldActive}>
                            <p className={cn(
                              "text-lg font-black text-slate-900 transition-all duration-500",
                              isFlashing && "bg-yellow-200 px-2 rounded"
                            )}>{allergies.join(', ') || 'None'}</p>
                          </PrivacyOverlay>
                        </div>

                        <div className="space-y-1">
                          <p className="text-sm font-bold text-slate-900 uppercase">Current Medications</p>
                          <PrivacyOverlay isActive={isPrivacyShieldActive}>
                            <p className="text-lg font-black text-slate-900 transition-all duration-500">
                              {medications.map(m => `${m.name} (${m.dosage})`).join(', ')}
                            </p>
                          </PrivacyOverlay>
                        </div>
                      </div>

                      <div className="bg-blue-100/50 p-6 rounded-2xl space-y-4">
                        <p className="text-sm font-bold text-slate-900 uppercase">Primary Contacts</p>
                        <div className="space-y-2">
                          {contacts.map(contact => (
                            <div key={contact.id} className="flex items-center justify-between">
                              <p className="text-sm font-bold text-slate-900">{contact.relation}: <span className="font-bold text-slate-900">{contact.name} ({contact.phone})</span></p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Right Column: Detailed Records */}
                    <div className="card w-full max-w-lg lg:max-w-none mx-auto p-4 md:p-6 mb-4 flex flex-col h-full relative border-t-blue-400">
                      <h2 className="text-2xl font-black text-slate-900">Detailed Records</h2>

                      <div className="space-y-6 flex-1">
                        {[
                          { id: 'mri', title: 'MRI Report', date: '(01/2026)', icon: FileText, color: 'text-slate-900' },
                          { id: 'vaccine', title: 'Vaccination History', date: '', icon: ShieldCheck, color: 'text-slate-900' },
                          { id: 'surgery', title: 'Surgical History', date: '(e.g., Appy 2018)', icon: History, color: 'text-slate-900' }
                        ].map((record) => (
                          <div 
                            key={record.id} 
                            onClick={() => handleViewRecord(record.id)}
                            className="flex items-center justify-between group cursor-pointer"
                          >
                            <div className="flex items-center gap-4">
                              <record.icon size={24} className={record.color} />
                              <PrivacyOverlay isActive={isPrivacyShieldActive && !authenticatedRecords.has(record.id)}>
                                <h4 className="font-bold text-slate-900 text-lg group-hover:text-blue-600 transition-all duration-500">
                                  {record.title} <span className="text-slate-500 font-medium text-sm">{record.date}</span>
                                </h4>
                              </PrivacyOverlay>
                            </div>
                            <div className="px-3 py-1 border-2 border-slate-300 rounded-lg text-[10px] font-bold uppercase flex items-center gap-1 group-hover:bg-slate-100 transition-all">
                              {(isUnmasked || authenticatedRecords.has(record.id)) ? <Eye size={12} /> : <Lock size={12} />} view
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile floating controls replaced by permanent, accessible UI and Top Header SOS button */}

        {/* Digital Wallet Health Card ID Presentation Overlay */}
        <AnimatePresence>
          {showHealthCard && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowHealthCard(false)}
              className="fixed inset-0 z-[2600] bg-slate-905/90 backdrop-blur-xl flex items-center justify-start sm:justify-center p-4 py-8 sm:p-6 overflow-y-auto"
            >
              <motion.div
                initial={{ scale: 0.92, y: 15 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.92, y: 15 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-slate-900 border-2 border-rose-500/30 w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden text-white flex flex-col relative max-h-[92vh] sm:max-h-[85vh] my-auto"
              >
                {/* Visual Header Grid Accent */}
                <div className="bg-gradient-to-r from-red-650 to-rose-600 px-6 py-6 text-center border-b border-white/10 relative shrink-0">
                  <span className="absolute left-6 top-6 bg-white/20 px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-widest text-white/90">
                    NFC LINKED
                  </span>
                  <div className="flex flex-col items-center">
                    <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center mb-2 leading-none">
                      <CreditCard size={20} className="text-white" />
                    </div>
                    <h3 className="text-sm font-extrabold tracking-[0.2em] text-white/90 uppercase">MedyCard Pro Digital ID</h3>
                    <p className="text-[9px] font-bold text-red-150 tracking-[0.1em] uppercase mt-0.5">Secure Offline Emergency Pass</p>
                  </div>
                  <button
                    onClick={() => setShowHealthCard(false)}
                    className="absolute right-6 top-6 w-8 h-8 rounded-full bg-black/20 hover:bg-black/45 flex items-center justify-center text-white/80 hover:text-white transition-all cursor-pointer"
                    title="Close"
                  >
                    <X size={16} />
                  </button>
                </div>

                {/* Secure Card Body Container - Scrollable for Mobile Viewport Safety */}
                <div className="p-6 space-y-5 text-left flex-1 bg-dots overflow-y-auto scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
                  {/* Blood Type & Heartrate Display */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-red-600/10 border border-red-500/20 rounded-2xl p-4 flex flex-col items-center justify-center text-center">
                      <p className="text-[10px] font-extrabold text-red-400 uppercase tracking-widest">Blood Group</p>
                      <p className="text-4xl font-black text-white mt-1.5">{bloodType || "O POSITIVE"}</p>
                    </div>
                    <div className="bg-white/5 border border-white/10 rounded-2xl p-4 flex flex-col items-center justify-center text-center">
                      <p className="text-[10px] font-extrabold text-slate-400 tracking-widest uppercase">Weight</p>
                      <p className="text-3xl font-black text-white mt-2">{weight || "78 kg"}</p>
                    </div>
                  </div>

                  {/* Red Alert Allergies Segment */}
                  <div className="bg-amber-600/10 border border-amber-500/20 rounded-2xl p-4 space-y-2">
                    <p className="text-[10px] font-extrabold text-amber-400 uppercase tracking-widest">Severe Allergies Alert</p>
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {allergies.map((alg) => (
                        <span key={alg} className="bg-amber-600/20 border border-amber-500/30 text-amber-200 text-[10.5px] font-black px-2.5 py-1 rounded-lg">
                          🚨 {alg}
                        </span>
                      ))}
                      {allergies.length === 0 && (
                        <span className="text-xs text-slate-400 italic">No severe allergies registered</span>
                      )}
                    </div>
                  </div>

                  {/* Medications List */}
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Active Life Medications</p>
                    <div className="space-y-1.5">
                      {medications.map((m) => (
                        <div key={m.id} className="flex justify-between items-center text-xs">
                          <span className="font-bold text-white/90">{m.name}</span>
                          <span className="font-semibold text-slate-400 font-mono text-[10.5px]">{m.dosage} — {m.frequency}</span>
                        </div>
                      ))}
                      {medications.length === 0 && (
                        <p className="text-xs text-slate-400 italic">No critical medications listed</p>
                      )}
                    </div>
                  </div>

                  {/* Contacts */}
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-2.5">
                    <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">Emergency Care Partners</p>
                    <div className="space-y-2">
                      {contacts.map((c) => (
                        <div key={c.id} className="flex justify-between items-center text-xs">
                          <div className="text-left">
                            <p className="font-black text-white/90">{c.name}</p>
                            <p className="text-[10px] text-slate-455 font-bold">{c.relation}</p>
                          </div>
                          <a
                            href={`tel:${c.phone}`}
                            className="bg-white/10 hover:bg-white/20 px-3 py-1 rounded-lg font-mono font-black border border-white/10 text-[10.5px]"
                          >
                            CALL {c.phone}
                          </a>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Authentic Barcode Simulation */}
                  <div className="bg-white rounded-xl px-4 py-3 border border-slate-200 text-center space-y-1">
                    <div className="h-10 flex justify-between items-stretch">
                      {Array.from({ length: 32 }).map((_, i) => {
                        const thickness = i % 2 === 0 ? "w-[1px]" : i % 3 === 0 ? "w-[3px]" : i % 5 === 0 ? "w-[4px]" : "w-[2px]";
                        const isGap = i % 7 === 0;
                        return (
                          <div
                            key={i}
                            className={cn(
                              "bg-slate-900 self-stretch",
                              thickness,
                              isGap && "bg-transparent"
                            )}
                          />
                        );
                      })}
                    </div>
                    <p className="text-[8px] font-black font-mono tracking-[0.3em] text-slate-500 uppercase">
                      MEDY-{appPin}-{bloodType.toUpperCase().replace(' ', '')}-NFC
                    </p>
                  </div>
                </div>

                {/* Screenshot Interactive Hint footer */}
                <div className="bg-slate-950/90 border-t border-white/10 p-4 text-center shrink-0 flex flex-col gap-2.5">
                  <p className="text-[10.5px] text-slate-350 leading-relaxed font-semibold">
                    💡 <span className="text-rose-400 font-black">PRO TIP:</span> Take a screenshot of this card to save as your lock screen wallpaper for absolute immediate retrieval!
                  </p>
                  <button 
                    onClick={() => setShowHealthCard(false)}
                    className="w-full bg-slate-800 hover:bg-slate-700 active:scale-[0.98] border border-white/15 text-white text-xs font-black py-2.5 px-4 rounded-xl transition-all cursor-pointer shadow-md"
                  >
                    CLOSE & SECURE CARD
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
